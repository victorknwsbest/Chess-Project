import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Observable;
import java.util.Observer;
import java.util.Optional;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;




/**
 * @authors: TEAM #9 - Fall 2021 - CS 335
 * @due date: December 8, 2021
 * 
 */
@SuppressWarnings("deprecation")
public class ChessView extends Application implements Observer {
	Scene homeScene, scene;
	Button homePlayButton= new Button("PLAY");
	Label homeLabel = new Label("CHESS");
	Label developers = new Label("Developed by: Team 9");
	
	private ChessController controller;
	private ChessController localController2;
	private MenuBar menubar;
	private NetworkDialog dialog;
    private Color white = Color.WHEAT;
    private Color black = Color.TAN;
    private boolean firstClick = true;
    private boolean twoClicks = false;
    private Point clickedFrom = new Point(0, 0);
    private Point clickedTo = new Point(0, 0);
    private ChessPiece[][] old = new ChessPiece[1][1];
    
    Color[] colors = {white,black}; 
    Optional<ButtonType> result;
    GridPane pane = new GridPane();
    VBox vbox = new VBox();
	private boolean isNetworkGame = false;
	private boolean isLocalGame = false;
	private boolean isLoadGame = false;
	
	@Override
	/**
	 * Creates the scene for the game, calls some other methods/
	 * classes needed for the program.
	 * 
	 * @param primaryStage(Stage)
	 * @return N/A
	 */
	public void start(Stage primaryStage) {
		
		String imageString = "images/game-mainpage.png";
    	Image image  = new Image(imageString);
        ImageView imageView = new ImageView(image); //Setting image view
        imageView.setImage(image);
        imageView.setPreserveRatio(true);
        imageView.setFitWidth(500);
        imageView.setTranslateX(0);
        imageView.setTranslateY(80);
        
        VBox layout = new VBox(20);   
		layout.setAlignment(Pos.CENTER);
		
		Font font = Font.font("Courier New", FontWeight.BOLD, 15);
		homeLabel.setFont(font);
		homeLabel.setStyle("-fx-text-fill: #d8dbd7");
		homeLabel.setScaleX(5);
		homeLabel.setScaleY(5);
		homeLabel.setTranslateY(-250);
		
		developers.setFont(font);
		developers.setStyle("-fx-text-fill: #d8dbd7");
		developers.setScaleX(1);
		developers.setScaleY(1);
		developers.setTranslateY(15);
		developers.setTranslateX(-120);
		
		homePlayButton.setTranslateY(-130);
		homePlayButton.setTranslateX(160);
		homePlayButton.setFont(font);
		homePlayButton.setStyle("-fx-background-color: #47a628; -fx-text-fill: #d8dbd7");
		
		homePlayButton.setOnAction(e -> primaryStage.setScene(scene));  
		layout.getChildren().addAll(imageView, developers, homeLabel, homePlayButton);
		homeScene = new Scene(layout, 450, 465);
		
		
		Button playButton = new Button("");
		playButton.setOnAction(e -> primaryStage.setScene(homeScene));
		VBox layout2= new VBox(20);
		layout2.getChildren().add(playButton);
		

		ChessModel model = new ChessModel("white", true);
		model.addObserver(this);
		controller = new ChessController(model);
		addMenu();
		createBoard();
		hoverMove();
		placePieces(controller.getBoard());
		addPositionsText();
		scene = new Scene(vbox, 450, 465);
		primaryStage.setTitle("Chess");
		primaryStage.setScene(homeScene);
		primaryStage.show();
	}
	
	/**
	 * Creates the gameboad; checkered board added.
	 * 
	 * Creates the gameboard; checkered board added.
	 * @param N/A
	 * @return N/A
	 */
	private void createBoard() {
		pane = new GridPane();
		pane.setHgap(0); //sets horizontal gap between components 
		pane.setVgap(0); //sets vertical gap between components
		pane.setPadding(new Insets(10));
		ChessPiece[][] gameBoard = controller.getBoard();
		for(int i = 0; i < gameBoard.length; i++) {
			for(int j = 0; j < gameBoard[i].length; j++) {	
				int temp = (i + j)  % 2;
				Rectangle square = new Rectangle();
				square.setWidth(50);
				square.setHeight(50);
				square.setStrokeType(StrokeType.OUTSIDE);
				square.setStrokeWidth(0); 
				square.setStroke(white);
				square.setTranslateX(10);
				GridPane.setRowIndex(square, i);
				GridPane.setColumnIndex(square, j);
				if(temp == 0) {	
					square.setFill(white);
				} else {
					square.setFill(black);
				}
				hoverMove();
				pane.getChildren().addAll(square);	
			} 
		}
		pane.setOnMouseClicked(event -> {
			clickPiece(event.getX(), event.getY());
		});
		vbox.getChildren().add(pane);
	}
	
	private void hoverMove() {
		
		ChessPiece[][] board = controller.getBoard();
		for(int i = 0; i < board.length; i++) {
			for(int j = 0; j < board[i].length; j++) {	
				int temp = (i + j)  % 2;
				Rectangle hover = new Rectangle();
				hover.setWidth(50);
				hover.setHeight(50);
				hover.setFill(Color.LIME);
				hover.setTranslateX(10);
				GridPane.setRowIndex(hover, i);
				GridPane.setColumnIndex(hover, j);
				if(temp == 0) {	
					hover.setFill(white);
				} else {
					hover.setFill(black);
				}
//				hover.setOnMouseMoved(new EventHandler<MouseEvent>() {
//
//					  @Override
//					  public void handle(final MouseEvent event) {
//
//					      System.out.println(event.getScreenX());
//					      System.out.println(event.getScreenY());
//					    }
//					});
				hover.setOnMouseEntered(new EventHandler<MouseEvent>() {

					  @Override
					  public void handle(final MouseEvent event) {
						  hover.setFill(Color.GREY);
					  }
					});
				hover.setOnMouseExited(new EventHandler<MouseEvent>() {

					  @Override
					  public void handle(final MouseEvent event) {
						  if(temp == 0) {	
								hover.setFill(white);

							} else {
								hover.setFill(black);
							}

					  }
					});
				hover.setOnMouseClicked(new EventHandler<MouseEvent>() {

					  @Override
					  public void handle(final MouseEvent event) {
						  hover.setFill(Color.LIME);
					  }
					});
			
			    pane.getChildren().addAll(hover);	 
			}
		}
	}
	
	/**
	 * Handles a click by the user.
	 * 
	 * @param x, y(double)
	 */
	private void clickPiece(double x, double y) {
		ChessPiece[][] board = controller.getBoard();
		// if no game has been started then clicks do nothing
		if(!isNetworkGame && !isLocalGame) {
			return;
		}
		// if not other player's turn on network then do nothing
		if(isNetworkGame && !controller.getMyTurn()) {
			return;
		}
		else if(x >= 25 && x <= 415 && y >= 20 && y <= 405) {
			int row = findRow(y);
			int col = findCol(x);
			
			// user's first click to choose which piece they want to move
			if(firstClick && twoClicks == false) {
				if(board[row][col] != null) {
					clickedFrom = new Point(row, col);
					firstClick = false;
				}
				else {
					firstClick = true;	
				}
			}
			// user's second click to choose where they want to move
			else if(!firstClick) {
				clickedTo = new Point(row, col);
				firstClick = true;
				twoClicks = true;
			}	
			// user has selected piece and where to move so do the move
			if(twoClicks) {
				twoClicks = false;
				// if network game then do a human turn to send message to other player
				if(isNetworkGame) {
					boolean validMove = controller.humanTurn(clickedFrom, clickedTo);
					// if valid move was made then end this turn, otherwise need to click again
					if(validMove) {
						controller.setMyTurn(false);
						// your click ended the game and you win
						if(controller.isGameOver() && controller.iWin()) {
							pane.setOnMouseClicked((event) -> {});
							userWinMessage(controller.getColor());
						}
						// your click ended the game and its a stalemate
						else if(controller.isGameOver() && controller.stalemate()) {
							pane.setOnMouseClicked((event) -> {});
							userTieMessage();
						}
					}
				}
				
				// if local game then switch player's color after making a valid move
				else if(isLocalGame) {
					// first player's turn to move
					if(controller.getMyTurn()) {
						boolean validLocalMove = false;
						if(controller.getHuman()) {
							validLocalMove = controller.move(clickedFrom, clickedTo);
						}
						// if player 1 made valid move then give player 2 a turn
						if(validLocalMove) {
							controller.setMyTurn(false);
							localController2.setMyTurn(true);
							localPlayer1GameOver();
							localController2.updateBoard(controller.getBoard());
						}
					}
					// second player's turn to move
					else if(localController2.getMyTurn() && localController2.getHuman()) {
						boolean validLocalMove = localController2.move(clickedFrom, clickedTo);
						// if player 2 made valid move then give player 1 a turn
						if(validLocalMove) {
							localController2.setMyTurn(false);
							controller.setMyTurn(true);
							localPlayer2GameOver();
							controller.updateBoard(localController2.getBoard());
						}
					}
					// computer turn for player 1
					if(controller.getMyTurn() && !controller.getHuman()) {
						if(controller.getMyDifficulty().equals("Easy")) {
							controller.makeEasyMove();
						}
						else if(controller.getMyDifficulty().equals("Hard")) {
							controller.makeHardMove();
						}
						controller.setMyTurn(false);
						localController2.setMyTurn(true);
						localPlayer1GameOver();
						localController2.updateBoard(controller.getBoard());
					}
					// computer turn for player 2
					else if(localController2.getMyTurn() && !localController2.getHuman()) {
						if(localController2.getMyDifficulty().equals("Easy")) {
							localController2.makeEasyMove();
						}
						else if(localController2.getMyDifficulty().equals("Hard")) {
							localController2.makeHardMove();
						}
						localController2.setMyTurn(false);
						controller.setMyTurn(true);
						localPlayer2GameOver();
						controller.updateBoard(localController2.getBoard());
					}
				}
			}
		}
	}

	/**
	 * Finds the correct row in the model's board based on the user's click
	 * @param y - a double representing the user's y coordinate for their click
	 * @return integer for the row depending on users click for the moving pieces.
	 */
	private int findRow(double y) {
		if (y >= 358 && y <= 405) {
			return 0;
		} else if (y >= 308 && y <= 357) {
			return 1;
		} else if (y >= 258 && y <= 307) {
			return 2;
		} else if (y >= 208 && y <= 257) {
			return 3;
		} else if (y >= 158 && y <= 207) {
			return 4;
		} else if (y >= 108 && y <= 157) {
			return 5;
		} else if (y >= 58 && y <= 107) {
			return 6;
		} else if (y >= 8 && y <= 57) {
			return 7;
		}
		return -1;
	}
	
	/**
	 * Finds the correct column in the model's board based on the user's click
	 * 
	 * @param x - a double representing the user's x coordinate for their click
	 * @return integer for the column depending on where user clicks for the moving pieces.
	 */
	private int findCol(double x) {
		if (x >= 25 && x <= 69) {
			return 0;
		} else if (x >= 70 && x <= 119) {
			return 1;
		} else if (x >= 120 && x <= 169) {
			return 2;
		} else if (x >= 170 && x <= 219) {
			return 3;
		} else if (x >= 220 && x <= 269) {
			return 4;
		} else if (x >= 270 && x <= 319) {
			return 5;
		} else if (x >= 315 && x <= 369) {
			return 6;
		} else if (x >= 370 && x <= 419) {
			return 7;
		}
		return -1;
	}
	
	/**
	 * Checks if the first local player has won, lost, or made the game
	 * end in a stalemate and shows the correct corresponding message.
	 */
	private void localPlayer1GameOver() {
		// if player 1 click is game over and they win
		if(controller.isGameOver() && controller.iWin()) {
			pane.setOnMouseClicked((event) -> {});
			localController2.setMyTurn(false);
			userWinMessage(controller.getColor());
		}
		// if player 1 click is game over and they lose
		else if(controller.isGameOver() && controller.iLose()) {
			pane.setOnMouseClicked((event) -> {});
			localController2.setMyTurn(false);
			userWinMessage(localController2.getColor());
		}
		// if player 1 click is game over and stalemate
		else if(controller.isGameOver() && controller.stalemate()) {
			pane.setOnMouseClicked((event) -> {});
			localController2.setMyTurn(false);
			userTieMessage();
		}
	}
	
	/**
	 * Checks if the 2nd local player has won, lost, or made the game
	 * end in a stalemate and shows the correct corresponding message.
	 */
	private void localPlayer2GameOver() {
		// if player 2 click is game over and they win
		if(localController2.isGameOver() && localController2.iWin()) {
			pane.setOnMouseClicked((event) -> {});
			controller.setMyTurn(false);
			userWinMessage(localController2.getColor());
		}
		// if player 2 click is game over and they lose
		else if(localController2.isGameOver() && localController2.iLose()) {
			pane.setOnMouseClicked((event) -> {});
			controller.setMyTurn(false);
			userWinMessage(controller.getColor());
		}
		// if player 2 click is game over and stalemate
		else if(localController2.isGameOver() && localController2.stalemate()) {
			pane.setOnMouseClicked((event) -> {});
			controller.setMyTurn(false);
			userTieMessage();
		}
	}

	/**
	 * Adds pieces to the game board. It will need to know which pieces to call
	 * based on the type, and then we will add the image for that piece depending 
	 * on the type that it is.
	 * 
	 * @param board which represents our gameboard as a 2d array.
	 * @return places pieces on board
	 */
	private void placePieces(ChessPiece[][] board) {
		ChessPiece[][] gameBoard = board;
		int x = 12;
		int y = 355;
		for(int row = 0; row < 8; row++) {
			for(int col = 0; col < 8; col++) {
				if(gameBoard[row][col] != null) {
					ChessPiece piece = gameBoard[row][col];
					Image image = null;
					
					String imageString = "images/" + piece.getColor().toLowerCase() + "-"
							+ piece.getPieceType().toLowerCase() + ".png";
	            	image  = new Image(getClass().getResource(imageString).toExternalForm());
		            
		            ImageView imageView = new ImageView(image); //Setting image view
		            imageView.setImage(image);
		            imageView.setPreserveRatio(true);
		            imageView.setFitWidth(50);
		            
		            imageView.setTranslateX(x);
		            imageView.setTranslateY(y);

		            pane.getChildren().addAll(imageView);

		        }
				x+=50;
			}
			x = 12;
			y-=50;
		}
	}

	/**
	 * Update is called to update the board in the view if any changes to the board
	 * are made by the model that the observable notifies the observers about.
	 * 
	 * @param o:	the observable in the model that notifies the view to update
	 * @param arg:	the 2d array that represents the board of the game
	 */
	@SuppressWarnings("unchecked")
	public void update(Observable o, Object arg) {
		ChessPiece[][] updatedBoard = (ChessPiece[][]) arg;
		vbox.getChildren().clear();
		addMenu();
		createBoard();
		placePieces(updatedBoard);
		addPositionsText();
	}	
	/**
	 * Adds the text for the positions on the side of the game board.
	 * The numbers will be displayed to the left of the board, vertically
	 * and going down from 8-1. The letters will be displayed at the bottom
	 * of the board. A-H in order, horizontally. 
	 * 
	 * @param N/A
	 * @return N/A
	 */
	private void addPositionsText() {
		int num;
		for(num = 8; num>=1;num--) {
			Label numPos = new Label();
			numPos.setText(String.valueOf(num));
			numPos.setTextFill(Color.BLACK);
			numPos.setFont(Font.font("SansSerif", 25));
			numPos.setTranslateX(-10);
			pane.add(numPos, 0,8-num);
		}
		
		char c;
		int a = 0;
		for(c = 'A'; c<='H';++c) {
			Label charPos = new Label();
			charPos.setText(String.valueOf(c));
			charPos.setTextFill(Color.BLACK);
			charPos.setFont(Font.font("SansSerif", 20));
			charPos.setTranslateX(30);
			pane.add(charPos, a, 8);
			a++;	
		}
	}
	
	/**
	 * This method adds a menu to the top of the canvas in javafx. The 
	 * menu will have options for a new game(network or local), the option
	 * to save the current game, to load a local game, to load the server's
	 * game, to load the client's game, to save and exit, and to exit
	 * 
	 * @param N/A
	 * @return N/A
	 */
	private void addMenu() {
		BorderPane root = new BorderPane(); 
		menubar = new MenuBar();  
		Menu FileMenu = new Menu("File");  
		MenuItem newNetworkGame = new MenuItem("New Network Game");
		MenuItem newLocalGame = new MenuItem("New Local Game");
		MenuItem saveGame = new MenuItem("Save");
		MenuItem loadGame = new MenuItem("Load Local Game");
		MenuItem loadServer = new MenuItem("Load Server");
		MenuItem loadClient = new MenuItem("Load Client");
		MenuItem saveExitGame = new MenuItem("Save & Exit");
		MenuItem exitGame = new MenuItem("Exit");
		newNetworkGame.setOnAction((event) -> {
			isLoadGame = false;
			boolean curNetwork = isNetworkGame;
			isNetworkGame = true;
			boolean curLocal = isLocalGame;
			isLocalGame = false;
			dialog = new NetworkDialog();
			// if user clicks ok to setup game then start game
			if(result.get().getText() == "OK") {
				try {
					startNetworkGame();
				} catch (ClassNotFoundException | IOException e) {
					e.printStackTrace();
				}
			}
			// otherwise user clicked cancel so no setup
			else {
				if(curLocal == true) {
					isLocalGame = true;
				}
				if(curNetwork == false) {
					isNetworkGame = false;
				}
				
			}
		});
		newLocalGame.setOnAction((event) -> {
			isLoadGame = false;
			boolean curLocal = isLocalGame;
			isLocalGame = true;
			boolean curNetwork = isNetworkGame;
			isNetworkGame = false;
			dialog = new NetworkDialog();
			// if user clicks ok to setup game then start game
			if(result.get().getText() == "OK") {
				isNetworkGame = false;
				try {
					startLocalGame();
				} catch (ClassNotFoundException | IOException e) {
					e.printStackTrace();
				} 
			}
			// otherwise user clicked cancel so no setup
			else {
				if(curNetwork == true) {
					isNetworkGame = true;
				}
				if(curLocal = false) {
					isLocalGame = false;
				}
				
			}
		});
		saveGame.setOnAction((event) -> {
			saveGameProgress();
		});
		loadGame.setOnAction((event) -> {
			isLoadGame = true;
			try {
				isLocalGame = true;
				startLocalGame();
			} catch (ClassNotFoundException | IOException e) {
				e.printStackTrace();
			} 
		});
		loadServer.setOnAction((event) -> {
			try {
				loadServer();
			} catch (ClassNotFoundException | IOException e) {
				e.printStackTrace();
			}
		});
		loadClient.setOnAction((event) -> {
			try {
				loadClient();
			} catch (ClassNotFoundException | IOException e) {
				e.printStackTrace();
			}
		});
		saveExitGame.setOnAction((event) -> {
			if(isNetworkGame ) {
				saveGameProgress();
				controller.exitNetwork();
			}
			else {
				saveGameProgress();
				System.exit(0);
			}
		});
		exitGame.setOnAction((event) -> {
			if(isNetworkGame ) {
				controller.exitNetwork();
			}
			else {
				System.exit(0);
			}
		});
		// add buttons to the file menu
		FileMenu.getItems().addAll(newNetworkGame, newLocalGame, saveGame, loadGame, loadServer, loadClient, saveExitGame, exitGame);  
		menubar.getMenus().addAll(FileMenu);  
		root.setTop(menubar);
		vbox.getChildren().addAll(root);
	}
	
	/**
	 * Loads the server's model by reading from the text file containing the 
	 * server's model. This can only be used when a game is not in progress.
	 * One instance must load the server first and another instance of the program
	 * must then load the client.
	 * 
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private void loadServer() throws ClassNotFoundException, IOException {
		if(isLocalGame || isNetworkGame) {
			return;
		}
		isNetworkGame = true;
		// read in server model from file and initialize controller with it
		ChessModel model;
		FileInputStream fileStream;
		fileStream = new FileInputStream("save-game-server.txt");
		ObjectInputStream objectStream = new ObjectInputStream(fileStream);
		model = (ChessModel) objectStream.readObject();
		controller = new ChessController(model);
		controller.newModel(model);
		model.addObserver(this);
		controller.newView(this);
		
		// create the gridPane
		vbox.getChildren().clear();
		addMenu();
		createBoard();
		placePieces(controller.getBoard());
		addPositionsText();
		
		controller.startServer(4000); 

		// if computer is server then first turn is computer turn
		if (!controller.getHuman() && controller.isServer()) {
			controller.computerTurn();
		}
	}
	
	/**
	 * Loads the client's model by reading from the text file containing the 
	 * client's model. This can only be used when a game is not in progress.
	 * One instance must load the server first and another instance of the program
	 * must then load the client.
	 * 
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	private void loadClient() throws ClassNotFoundException, IOException {
		if(isLocalGame || isNetworkGame) {
			return;
		}
		// read in client model from file and initialize controller with it
		isNetworkGame = true;
		ChessModel model;
		FileInputStream fileStream;
		fileStream = new FileInputStream("save-game-client.txt");
		ObjectInputStream objectStream = new ObjectInputStream(fileStream);
		model = (ChessModel) objectStream.readObject();
		controller = new ChessController(model);
		controller.newModel(model);
		model.addObserver(this);
		controller.newView(this);
		
		// create the gridPane
		vbox.getChildren().clear();
		addMenu();
		createBoard();
		placePieces(controller.getBoard());
		addPositionsText();
		
		controller.startClient("localhost", 4000);

		// if client then send message to server
		if (!controller.isServer()) {
			controller.sendMessage();
		}
	}

	/**
	 * Saves the current game's model by writing the model to a text file depending on
	 * whether a local or network game is being played, and if the player is the server
	 * or client.
	 * 
	 * @param N/A
	 * @return N/A
	 */
	public void saveGameProgress() {
		if(isLocalGame || isNetworkGame) {
			//BufferedWriter writeOutput = null;
			FileOutputStream fileStream = null;
	        ObjectOutputStream objectStream = null;
			try {
				File file = null;
				if(isLocalGame) {
					file = new File("save-game.txt");
				}
				else {
					if(controller.isServer()) {
						file = new File("save-game-server.txt");
					}
					else {
						file = new File("save-game-client.txt");
					}
				}
				
				fileStream = new FileOutputStream(file);   
		        objectStream = new ObjectOutputStream(fileStream);
		        // write model for player
				ChessModel model = controller.getModel();
				objectStream.writeObject(model);
				// if local game then write model for 2nd player
				if(isLocalGame) {
					ChessModel model2 = localController2.getModel();
					objectStream.writeObject(model2);
				}
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
			if (objectStream != null) {
				try {
					//writeOutput.close();
					objectStream.close();
					fileStream.close();
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * This method adds the user message for when there's a winner.
	 * @param color 
	 * @param N/A
	 * @return N/A
	 */
	public void userWinMessage(String color) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Message");
		alert.setHeaderText("Message");
		if(isNetworkGame) {
			alert.setContentText("You Won!");
		}
		else if(isLocalGame) {
			alert.setContentText(color + " Won!");
		}
		alert.showAndWait();
	}
	
	/**
	 * This method adds the user message for when there's a loser.
	 * @param color 
	 * @param N/A
	 * @return N/A
	 */
	public void userLoseMessage(String color) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Message");
		alert.setHeaderText("Message");
		if(isNetworkGame) {
			alert.setContentText("You lose");
		}
		else if(isLocalGame) {
			alert.setContentText(color + " Lost");
		}
		alert.showAndWait();
	}
	
	/**
	 * This method adds the user message for when there's a stalemate.
	 * @param N/A
	 * @return N/A
	 */
	public void userTieMessage() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Message");
		alert.setHeaderText("Message");
		alert.setContentText("Stalemate");
		alert.showAndWait();
	}
	
	/**
	 * Starts a local multiplayer game in one instance of the program
	 * 
	 * @param N/A
	 * @return N/A
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	private void startLocalGame() throws ClassNotFoundException, IOException {
		isLocalGame = true;
		ChessModel model;
		ChessModel model2;
		if(isLoadGame) {
			FileInputStream fileStream = new FileInputStream("save-game.txt");   
		    ObjectInputStream objectStream = new ObjectInputStream(fileStream);
			model = (ChessModel) objectStream.readObject();
			controller = new ChessController(model);
			controller.newModel(model);
			model.addObserver(this);
			controller.newView(this);
			
			model2 = (ChessModel) objectStream.readObject();
			localController2 = new ChessController(model2);
			localController2.newModel(model2);
			model2.addObserver(this);
			localController2.newView(this);
			objectStream.close();
			fileStream.close();
		}
		else {
			model = new ChessModel("white", dialog.humanOrComputer());
			controller.newModel(model);
			model.addObserver(this);
			controller.setMyDifficulty(dialog.getDifficulty());
			controller.newView(this);
			controller.setMyTurn(true);
			// 2nd local player
			model2 = new ChessModel("black", dialog.humanOrComputer2());
			localController2 = new ChessController(model2);
			model2.addObserver(this);
			localController2.setMyDifficulty(dialog.getDifficulty2());
			localController2.newView(this);
			localController2.setMyTurn(false);
		}
		
		// create the gridPane
		vbox.getChildren().clear();
		addMenu();
		createBoard();
		placePieces(controller.getBoard());
		addPositionsText();
		
		// if player 1 is computer player and player 2 is human then make a move
		if(!controller.getHuman() && controller.getMyTurn() && localController2.getHuman()) {
			if(controller.getMyDifficulty() == "Easy") {
				controller.makeEasyMove();
			}
			else if(controller.getMyDifficulty() == "Hard") {
				controller.makeHardMove();
			}
			controller.setMyTurn(false);
			localController2.setMyTurn(true);
			localController2.updateBoard(controller.getBoard());
		}
		
		// if both players computers then do computer moves until game over
		else if (!controller.getHuman() && !localController2.getHuman()) {
			while(!controller.isGameOver() && !localController2.isGameOver()) {
				// computer turn for player 1
				if (controller.getMyTurn()) {
					if(controller.getMyDifficulty().equals("Easy")) {
						controller.makeEasyMove();
					}
					else if(controller.getMyDifficulty().equals("Hard")) {
						controller.makeHardMove();
					}
					controller.setMyTurn(false);
					localController2.setMyTurn(true);
					localController2.updateBoard(controller.getBoard());

				}
				// computer turn for player 2
				else if (localController2.getMyTurn()) {
					if(localController2.getMyDifficulty().equals("Easy")) {
						localController2.makeEasyMove();
					}
					else if(localController2.getMyDifficulty().equals("Hard")) {
						localController2.makeHardMove();
					}
					localController2.setMyTurn(false);
					controller.setMyTurn(true);
					controller.updateBoard(localController2.getBoard());
				}
			}
			// check if player 1 won or stalemate
			if(controller.isGameOver() && (controller.iWin() || controller.stalemate())) {
				localPlayer1GameOver();
			}
			// check if player 2 won or stalemate
			else if (localController2.isGameOver() && (localController2.iWin() || localController2.stalemate())){
				localPlayer2GameOver();
			}
		}
	}
	
	/**
	 * Begins the network multiplayer game in its starting state with one instance
	 * functioning as the server and another instance connecting to it as the client
	 * 
	 * @param N/A
	 * @return N/A
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	private void startNetworkGame() throws ClassNotFoundException, IOException {
		isNetworkGame = true;
		ChessModel model = new ChessModel("white", true);
		controller.newModel(model);
		model.addObserver(this);
		controller.newView(this);

		// create the gridPane
		vbox.getChildren().clear();
		addMenu();
		createBoard();
		placePieces(controller.getBoard());
		addPositionsText();

		// networking based on dialog buttons that were toggled
		String currPlayer = "white";
		// if picked server then start the server
		if (dialog.serverOrClient()) {
			controller.startServer(dialog.serverPort());
		}
		// if picked client then start the client
		else {
			currPlayer = "black";
			controller.startClient(dialog.serverAddress(), dialog.serverPort());
		}
		controller.setColor(currPlayer);
		controller.setHuman(dialog.humanOrComputer());
		controller.setMyDifficulty(dialog.getDifficulty());

		// if client then send message to server
		if (!dialog.serverOrClient()) {
			controller.sendMessage();
		}
		// if computer is server then first turn is computer turn
		else if (!dialog.humanOrComputer() && dialog.serverOrClient()) {
			controller.computerTurn();
		}
	}
	
	/**
	 * Dialog is a private class that extends stage and displays the dialog box
	 * and uses initModality(Modality.APPLICATION_MODAL) to make it act as a 
	 * modal dialog. The user selects which role they want, either server or client,
	 * and if the player will be a human or the AI. The class provides methods that
	 * query the object for what selections the user made to setup the game.
	 * @author Team9
	 */
	private class NetworkDialog extends Stage {

		private TextField server;
		private TextField port;
		private ToggleGroup serverClient;
		private ToggleGroup player;
		private ToggleGroup player2;
		private ToggleGroup difficulty;
		private ToggleGroup difficulty2;

		/**
		 * Constructor that displays the modal dialog and allows the user to select the
		 * options they want for the role, human or AI, and the server address and port.
		 */
		public NetworkDialog() {
			DialogPane dialogPane = new DialogPane();
			dialogPane.setMinWidth(300);
			dialogPane.setMinHeight(150);

			Alert dialogAlert = new Alert(AlertType.NONE);
			if(isNetworkGame) {
				dialogAlert.setTitle("Network Setup");
			}
			else {
				dialogAlert.setTitle("Local Multiplayer Setup");
			}
			
			dialogAlert.initModality(Modality.APPLICATION_MODAL);
			HBox serverClientBox = new HBox(10);
			if(isNetworkGame) {
				// make toggle for server
				serverClient = new ToggleGroup();
				RadioButton serverButton = new RadioButton("Server");
				serverButton.setToggleGroup(serverClient);
				serverButton.setMinWidth(90);
				serverButton.setSelected(true);
				// make toggle for client
				RadioButton clientButton = new RadioButton("Client");
				clientButton.setMinWidth(90);
				clientButton.setToggleGroup(serverClient);
				Text create = new Text("   Create: ");
				serverClientBox.getChildren().addAll(create, serverButton, clientButton);	
			}

			// make toggle for human
			Text player1Text = new Text("   Player 1:     ");
			Text player2Text = new Text("   Player 2:     ");
			Text playAs = new Text("   Play as: ");
			Text netDifficulty = new Text("  Player AI: ");
			Text difficultyText1 = new Text("   Player 1 AI: ");
			Text difficultyText2 = new Text("   Player 2 AI: ");
			player = new ToggleGroup();
			player2 = new ToggleGroup();
			// make toggle for human
			RadioButton humanButton = new RadioButton("Human");
			humanButton.setToggleGroup(player);
			humanButton.setMinWidth(90);
			humanButton.setSelected(true);
			// make human toggle for possible 2nd local player
			RadioButton humanButton2 = new RadioButton("Human");
			humanButton2.setToggleGroup(player2);
			humanButton2.setMinWidth(90);
			humanButton2.setSelected(true);
			HBox humanCompButton = new HBox(10);
			// make toggle for computer
			RadioButton compButton = new RadioButton("Computer");
			compButton.setMinWidth(90);
			compButton.setToggleGroup(player);
			// make computer toggle for possible 2nd local player
			RadioButton compButton2 = new RadioButton("Computer");
			compButton2.setMinWidth(90);
			compButton2.setToggleGroup(player2);
			
			HBox humanCompButton2 = new HBox(10);
			HBox difficultyButton = new HBox(10);
			HBox difficultyButton2 = new HBox(10);
			difficulty = new ToggleGroup();
			difficulty2 = new ToggleGroup();
			// set easy toggle
			RadioButton easyButton = new RadioButton("Easy");
			easyButton.setMinWidth(90);
			easyButton.setToggleGroup(difficulty);
			easyButton.setSelected(true);
			// set hard toggle
			RadioButton hardButton = new RadioButton("Hard");
			hardButton.setMinWidth(90);
			hardButton.setToggleGroup(difficulty);
			// set easy toggle for possible 2nd local player
			RadioButton easyButton2 = new RadioButton("Easy");
			easyButton2.setMinWidth(90);
			easyButton2.setToggleGroup(difficulty2);
			easyButton2.setSelected(true);
			// set hard toggle for possible 2nd local player
			RadioButton hardButton2 = new RadioButton("Hard");
			hardButton2.setMinWidth(90);
			hardButton2.setToggleGroup(difficulty2);
			
			if(isLocalGame) {
				humanCompButton.getChildren().addAll(player1Text, humanButton, compButton);
				difficultyButton.getChildren().addAll(difficultyText1, easyButton, hardButton);
				humanCompButton2.getChildren().addAll(player2Text, humanButton2, compButton2);
				difficultyButton2.getChildren().addAll(difficultyText2, easyButton2, hardButton2);
			}
			else if(isNetworkGame) {
				humanCompButton.getChildren().addAll(playAs, humanButton, compButton);
				difficultyButton.getChildren().addAll(netDifficulty, easyButton, hardButton);
			}
			

			HBox hbox = new HBox(10);
			if(isNetworkGame) {
				// port text field
				port = new TextField("4000");
				port.setMinWidth(100);
				port.setText("4000");
				Text portText = new Text("Port");
				// server text field
				server = new TextField("localhost");
				server.setMinWidth(100);
				server.setText("localhost");
				Text serverText = new Text("   Server");
				// add server and port text to box
				hbox.getChildren().addAll(serverText, server, portText, port);
			}

			// add buttons and text fields to box
			VBox vbox = new VBox(6);
			vbox.getChildren().addAll(serverClientBox, humanCompButton, difficultyButton, humanCompButton2, difficultyButton2, hbox);

			// add everything to dialogPane then show and wait
			dialogPane.getChildren().addAll(vbox);
			dialogAlert.setDialogPane(dialogPane);
			ButtonType ok = new ButtonType("OK");
			ButtonType cancel = new ButtonType("Cancel");
			dialogAlert.getButtonTypes().addAll(ok, cancel);
			result = dialogAlert.showAndWait();
		}

		/**
		 * Determines whether this instance of the game is acting as
		 * a Server or a Client.
		 * 
		 * @param N/A
		 * @return boolean:	true for Server, false for Client.
		 */
		public boolean serverOrClient() {
			if (serverClient.getSelectedToggle().toString().contains("Server")) {
				return true;
			}
			return false;
		}

		/**
		 * Determines whether this instance of the game 
		 * is human-controlled or computer-controlled.
		 * 
		 * @param N/A
		 * @return boolean:	true if human, false if computer.
		 */
		public boolean humanOrComputer() {
			if (player.getSelectedToggle().toString().contains("Human")) {
				return true;
			}
			return false;
		}
		
		/**
		 * Determines whether this instance of the game 
		 * is human-controlled or computer-controlled.
		 * 
		 * @return boolean:	true if human, false if computer.
		 */
		public boolean humanOrComputer2() {
			if (player2.getSelectedToggle().toString().contains("Human")) {
				return true;
			}
			return false;
		}
		
		/**
		 * Determines whether this instance of the game 
		 * is human-controlled or computer-controlled.
		 * 
		 * @param N/A
		 * @return String: string representing the difficulty selected by the user
		 */
		public String getDifficulty() {
			if(difficulty.getSelectedToggle().toString().contains("Easy")) {
				return "Easy";
			}
			else if (difficulty.getSelectedToggle().toString().contains("Hard")) {
				return "Hard";
			}
			return "";
		}
		
		/**
		 * Determines whether this instance of the game 
		 * is human-controlled or computer-controlled.
		 * 
		 * @param N/A
		 * @return String: string representing the difficulty selected by the user
		 */
		public String getDifficulty2() {
			if(difficulty2.getSelectedToggle().toString().contains("Easy")) {
				return "Easy";
			}
			else if (difficulty2.getSelectedToggle().toString().contains("Hard")) {
				return "Hard";
			}
			return "";
		}

		/**
		 * Returns the server name, or address.
		 * 
		 * @param N/A
		 * @return String:	the name of the Server.
		 */
		public String serverAddress() {
			return server.getText();
		}

		/**
		 * Returns the port being used to connect.
		 * 
		 * @param N/A
		 * @return int:	the port number.
		 */
		public int serverPort() {
			return Integer.parseInt(port.getText());
		}
	}
}