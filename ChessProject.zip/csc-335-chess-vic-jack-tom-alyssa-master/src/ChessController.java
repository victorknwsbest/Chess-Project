import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import javafx.application.Platform;

/**
 * Chess controller class, responsible for using the model through getters and
 * setters to make the Chess game function. Also contains methods for networking
 * used for starting a game between a server and client
 * 
 * @author Jack, Alyssa, Tom, Victor
 *
 */
public class ChessController implements Serializable {
	private ChessModel model;
	private ChessView view;
	private ChessMoveMessage otherMsg;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private Socket connection;
	private boolean isServer = false;
	private boolean isConnected = false;

	/**
	 * Constructor for chess controller
	 * @param model
	 */
	public ChessController(ChessModel model) {
		this.model = model;
	}
	
	/**
	 * model creates a new ChessMoveMessage that is used to send a message to
	 * the other player connected on the network when one player made a move
	 * 
	 * @param	from is the starting position of the move
	 * @param	to is the destination of the move	
	 * @return	ChessMoveMessage is returned containing information about which piece moved
	 */
	public ChessMoveMessage moveMessage(ChessPiece[][] newBoard) {
		return model.moveMessage(newBoard);
	}
	
	/**
	 * Returns if the this controller is the server or not
	 * 
	 * @return boolean true if controller is server, false if not
	 */
	public boolean isServer() {
		return isServer;
	}

	/**
	 * Sets the player's turn to true or false
	 * 
	 * @param turn: the boolean for the player's turn
	 */
	public void setMyTurn(boolean turn) {
		model.setMyTurn(turn);
	}

	/**
	 * Returns whether it is this player's turn
	 * 
	 * @return true if it is their turn, false if not
	 */
	public boolean getMyTurn() {
		return model.getMyTurn();
	}

	/**
	 * Returns true if the player is a human, false if the player is computer
	 * 
	 * @return boolean:	Returns whether this instance is human or a computer
	 */
	public boolean getHuman() {
		return model.getHuman();
	}
	
	/**
	 * Sets true if player is human, false if not
	 * 
	 * @param human is true or false for if player is human
	 */
	public void setHuman(boolean human) {
		model.setHuman(human);
	}
	
	/**
	 * Returns the player's color, black or white
	 * 
	 * @return String:	black or white for player's color
	 */
	public String getColor() {
		return model.getColor();
	}
	
	/**
	 * Sets the player's color to black or white
	 * 
	 * @param color is black or white for player's color
	 */
	public void setColor(String color) {
		model.setColor(color);
	}
	
	/**
	 * Sets the player's difficulty for this AI player
	 * 
	 * @param difficulty: the string representing the player AI's difficulty
	 */
	public void setMyDifficulty(String difficulty) {
		model.setMyDifficulty(difficulty);;
	}

	/**
	 * Returns the selected difficulty for this AI player
	 * 
	 * @return String: the player's AI difficulty
	 */
	public String getMyDifficulty() {
		return model.getMyDifficulty();
	}
	
	/**
	 * Executes a random move using the model and returns if the move was
	 * completed
	 * 
	 * @return boolean representing if the move made was completed
	 */
	public boolean makeRandomMove() {
		return model.makeRandomMove();
	}
	
	/**
	 * Executes an easy move using the model and returns if the move was
	 * completed
	 * @return boolean representing if the move made was completed
	 */
	public boolean makeEasyMove() {
		return model.makeEasyMove();
	}
	
	/**
	 * Executes a hard move using the model and returns if the move was
	 * completed
	 * 
	 * @return boolean representing if the move made was completed
	 */
	public boolean makeHardMove() {
		return model.makeHardMove();
	}
	
	/**
	 * Starts the server allowing a client to connect to it. A server socket is created
	 * and accepts the connection to the server. The input and output streams are initialized
	 * and the player's turn is set to true since the server will go first.
	 * 
	 * @param	port is the int value that is used for the server port
	 */
	@SuppressWarnings("resource")
	public void startServer(int port) {
		try {
			connection = null;
			ServerSocket server = new ServerSocket(port);
			connection = server.accept();
			server.close();
			oos = new ObjectOutputStream(connection.getOutputStream());
			ois = new ObjectInputStream(connection.getInputStream());
			isServer = true;
			isConnected = true;
			setMyTurn(true);
		} 
		catch (IOException e) {
			System.err.println("Something went wrong with the network! " + e.getMessage());
		}
	}
	
	/**
	 * Starts a client which connects to the server using the address and port. A socket is created
	 * to connect to the server and the input and output streams are initialized for this connection.
	 * 
	 * @param	address is the server address
	 * @param	port is the int value that is used for the server port
	 */
	public void startClient(String address, int port) { 
		try {
			connection = new Socket(address, port); 
			isConnected = true;
			oos = new ObjectOutputStream(connection.getOutputStream());
			ois = new ObjectInputStream(connection.getInputStream());
		}
		catch (IOException e) {
			System.err.println("Something went wrong with the network! " + e.getMessage());
		}
	}
	
	/**
	 * Sends a ChessMoveMessage across the Server-Client connection to tell other 
	 * player that a move has been made.
	 * 
	 * @param N/A
	 * @return N/A
	 */
	public void sendMessage() {
		if(!isConnected ) { 
			return; 
		}
		Thread t = new Thread(() -> {
			otherMsg = null;
			try {
				otherMsg = (ChessMoveMessage) ois.readObject();
				Platform.runLater(() -> {
					model.updateBoard(otherMsg.getUpdatedBoard());
					// this player loses
					if (model.isGameOver() && model.iLose()) {
						view.userLoseMessage(model.getColor());
						setMyTurn(false);
					}
					// game ends in a stalemate
					else if (model.isGameOver() && model.stalemate()) {
						view.userTieMessage();
						setMyTurn(false);
					}
					// if not human turn then do computer turn
					else if (!model.isGameOver() && model.getHuman() == false) {
						computerTurn();
					}
				});
			} 
			// if no socket then do nothing, user closes other instance manually
			catch (SocketException e) {
			}
			catch (ClassNotFoundException | IOException e) {
				System.err.println("Something went wrong with serialization: " + e.getMessage());
			}
			model.setMyTurn(true);
		});
		t.start();
	}
	
	/**
	 * Exits from a networked multiplayer game by first sending a message
	 * to the other player and then exiting.
	 * 
	 * @param N/A
	 * @return N/A
	 */
	public void exitNetwork() {
		sendMessage();
		System.exit(0);	
	}
	
	/**
	 * Human player makes a move and the move is sent to the other player. A good move
	 * must be made by the player so that their turn ends and the other player is notified
	 * of a move being made.
	 * 
	 * @param	from is the starting position of the move
	 * @param	to is the destination of the move
	 */
	public boolean humanTurn(Point from, Point to) {
		boolean goodMove = this.model.movePiece(from, to);
		if(!goodMove) {
			return false;
		}
		try {
			oos.writeObject(this.model.moveMessage(model.getBoard()));
		} 
		catch (IOException e) {
			System.err.println("Something went wrong with serialization: " + e.getMessage());
		}
		this.sendMessage();
		return true;
	}
	
	/**
	 * Computer player makes a move based on the difficulty and the move is sent to the other player
	 * 
	 * @param	from is the starting position of the move
	 * @param	to is the destination of the move
	 */
	public void computerTurn() {
		if(model.getMyDifficulty().equals("Easy")) {
			model.makeEasyMove();
		}
		else if(model.getMyDifficulty().equals("Hard"))  {
			model.makeHardMove();
		}
		
		try {
			oos.writeObject(this.model.moveMessage(model.getBoard()));
		} 
		catch (IOException e) {
			System.err.println("Something went wrong with serialization: " + e.getMessage());
		}
		// if game over then computer wins
		if(model.isGameOver() && model.iWin()) {
			view.userWinMessage(model.getColor());
		}
		// if game over but nobody won then draw
		else if(model.isGameOver() && model.stalemate()) {
			view.userTieMessage();
		}
		model.setMyTurn(false);
		this.sendMessage();
	}
	
	/**
	 * Returns true if a move was successful and false if not
	 * 
	 * @param from
	 * @param to
	 * @return boolean true/false
	 */
	public boolean move(Point from, Point to) {
		return this.model.movePiece(from, to);
	}
	/**
	 * Returns true if the path for a piece moving from one position
	 * to another position is clear
	 * 
	 * @param start
	 * @param end
	 * @return boolean true/false
	 */
	public boolean isPathClear(Point start, Point end) {
		return this.model.isPathClear(start, end);
	}
	/**
	 * Returns true if a piece is in check
	 * 
	 * @return boolean true/false
	 */
	public boolean inCheck() {
		return this.model.inCheck(this.getColor());
	}
	
	/**
	 * Returns true if the game is over by checkmate or stalemate 
	 * 
	 * @return boolean true/false
	 */
	boolean isGameOver() {
		return this.model.isGameOver();
	}
	
	/**
	 * Getter for the board containing all of the pieces
	 * 
	 * @return gameboard 
	 */
	public ChessPiece[][] getBoard() {
		return model.getBoard();
	}
	
	/**
	 * Sets the model for the controller to be equal to a new model
	 * 
	 * @param chessModel
	 */
	public void newModel(ChessModel chessModel) {
		this.model = chessModel;
	}
	
	/**
	 * Getter for the model
	 * 
	 * @return ChessModel the model for the controller
	 */
	public ChessModel getModel() {
		return model;
	}
	
	/**
	 * Sets the view for the controller to be equal to a new view
	 * 
	 * @param chessView
	 */
	public void newView(ChessView chessView) {
		this.view = chessView;
	}

	/**
	 * Updates the model's board with a new board passed as an 
	 * argument
	 * 
	 * @param board is the game board containing the pieces
	 */
	public void updateBoard(ChessPiece[][] board) {
		model.updateBoard(board);
		
	}
	
	/**
	 * Returns if the player is the winner
	 * 
	 * @return boolean representing if the player has won
	 */
	public boolean iWin() {
		return model.iWin();
	}

	/**
	 * Returns if the player is the loser
	 * 
	 * @return boolean representing if the player has lost
	 */
	public boolean iLose() {
		return model.iLose();
	}

	/**
	 * Returns if the game ends in a stalemate
	 * 
	 * @return boolean representing if the player has won
	 */
	public boolean stalemate() {
		return model.stalemate();
	}
}

