import java.io.Serializable;

/**
 * @author Team9
 * 
 * This class serves as a representation of a rook piece,
 * will be using the ChessPiece class that we have also 
 * created. 
 */

public class Rook extends ChessPiece implements Serializable {
	/**
	 * Constructor
	 * @param color that the piece needs to be depending on the player.
	 * @param pieceType represents the type of the piece.
	 * @param position of what this piece needs to be at.
	 */
	public Rook(String color, String pieceType, Point position) {
		super(color, pieceType, position);
	}

	@Override
	void resetReach() {
		reachableSpaces.clear();
		for (int row = 0; row < 8; row++) {
			Point reachable = new Point(row, position.col);
			if (reachable.equals(position))
				continue;
			reachableSpaces.add(reachable);
		}
		for (int col = 0; col < 8; col++) {
			Point reachable = new Point(position.row, col);
			if (reachable.equals(position))
				continue;
			reachableSpaces.add(reachable);
		}
	}
	
}
