import java.util.concurrent.ThreadLocalRandom;
import java.util.AbstractMap.SimpleEntry;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Observable;
import java.util.Set;

/*
 * 
 */
@SuppressWarnings("deprecation")
public class ChessModel extends Observable implements Serializable{	
	private ChessPiece[][] board;
	private String color;
	private boolean myTurn;
	private boolean human; 
	private String myDifficulty;
	private boolean canCastleKingside;
	private boolean canCastleQueenside;
	private boolean allowPinPull = false;
	private boolean gameOverBlock = false;

	/**
	 * Constructor
	 * @param color: either the String "white" or "black"
	 * @return an instance of ChessModel 
	 */
	public ChessModel(String color, boolean human) {
		this.color = color;
		this.human = human;
		initializeBoard();
	}

	/**
	 * Initialize the game board, and set it up in starting position.
	 */
	private void initializeBoard() {
		board = new ChessPiece[8][8];
		
		for (int col = 0; col < 8; col++) {
			int row = 1;
			board[row][col] = new Pawn("white", "pawn", new Point(row, col));
			row = 6;
			board[row][col] = new Pawn("black", "pawn", new Point(row, col));
		}
		board[0][0] = new Rook  ("white", "rook",   new Point(0, 0));
		board[0][1] = new Knight("white", "knight", new Point(0, 1));
		board[0][2] = new Bishop("white", "bishop", new Point(0, 2));
		board[0][3] = new Queen ("white", "queen",  new Point(0, 3));
		board[0][4] = new King  ("white", "king",   new Point(0, 4));
		board[0][5] = new Bishop("white", "bishop", new Point(0, 5));
		board[0][6] = new Knight("white", "knight", new Point(0, 6));
		board[0][7] = new Rook  ("white", "rook",   new Point(0, 7));
		
		board[7][0] = new Rook  ("black", "rook",   new Point(7, 0));
		board[7][1] = new Knight("black", "knight", new Point(7, 1));
		board[7][2] = new Bishop("black", "bishop", new Point(7, 2));
		board[7][3] = new Queen ("black", "queen",  new Point(7, 3));
		board[7][4] = new King  ("black", "king",   new Point(7, 4));
		board[7][5] = new Bishop("black", "bishop", new Point(7, 5));
		board[7][6] = new Knight("black", "knight", new Point(7, 6));
		board[7][7] = new Rook  ("black", "rook",   new Point(7, 7));
		
		canCastleKingside = true;
		canCastleQueenside = true;
	}
	
	/**
	 * Overloader for getBoard() - both methods are identical.
	 * @return ChessPiece[][]: the grid-shaped data structure for the chess board.
	 */
	public ChessPiece[][] getGrid() {
		return board;
	}
	
	/**
	 * Returns the array of arrays of ChessPiece objects.
	 * board[0][0] refers to the BOTTOM-LEFT space of the board (from white's perspective),
	 * and board[7][7] refers to the TOP-RIGHT space.
	 * Empty spaces contain a null value.
	 * @return ChessPiece[][]: the grid-shaped data structure for the chess board.
	 */
	public ChessPiece[][] getBoard() {
		return board;
	}
	
	/**
	 * Sets the player's difficulty for this AI player
	 * 
	 * @param difficulty: the string representing the player AI's difficulty
	 */
	public void setMyDifficulty(String difficulty) {
		this.myDifficulty = difficulty;
	}

	/**
	 * Returns the selected difficulty for this AI player
	 * @return String: the player's AI difficulty
	 */
	public String getMyDifficulty() {
		return myDifficulty;
	}
	
	/**
	 * Sets the player's turn to true or false
	 * 
	 * @param turn: true if it is this player's turn, false otherwise
	 */
	public void setMyTurn(boolean turn) {
		this.myTurn = turn;
	}

	/**
	 * Returns whether it is this player's turn
	 * @return boolean: true if it is this player's turn, false if not
	 */
	public boolean getMyTurn() {
		return myTurn;
	}

	/**
	 * Returns true if the player is a human, false if the player is computer
	 * @return boolean:	true if the player is a human, false if the player is computer
	 */
	public boolean getHuman() {
		return human;
	}
	
	/**
	 * Sets true if player is human, false if not
	 * 
	 * @param human: true if the player is a human, false if the player is computer
	 */
	public void setHuman(boolean human) {
		this.human = human;
	}
	
	/**
	 * Returns the player's color, black or white
	 * @return String: either "black" or "white"
	 */
	public String getColor() {
		return color;
	}
	
	/**
	 * Sets this player's color.
	 * 
	 * @return String: either "black" or "white"
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * Creates a new ChessMoveMessage which contains information about the 
	 * start position and destination of a move. It is used to send a message to
	 * the other player on the network about where a piece has moved.
	 * 
	 * @param from is the starting position of the move
	 * @param to is the destination of the move
	 * @return ChessMoveMessage: a message that contains information about move
	 */
	public ChessMoveMessage moveMessage(ChessPiece[][] newBoard) {
		return new ChessMoveMessage(newBoard);
	}
	
	/**
	 * Updates the board with the new board after a move has been made by the other 
	 * opponent
	 * @param updateBoard(ChessPiece)
	 * @return N/A
	 */
	public void updateBoard(ChessPiece[][] updatedBoard) {
		board = updatedBoard;
		setChanged();
		notifyObservers(updatedBoard);
	}
	
	/**
	 * Overloader for getPieceAtLocation (below)
	 * Takes separate row and col int coordinates instead of a Point object.
	 * @param row, col values
	 * @return the ChessPiece object at the given location, or null if there is none
	 */
	public ChessPiece getPieceAtLocation(int row, int col) {
		return board[row][col];
	}
	
	/**
	 * Returns the piece contained at a given space on the board.
	 * Returns null if the space is empty.
	 * @param loc: a Point object with row val (0-7) and col val (0-7)
	 * @return the ChessPiece object at the given location, or null if there is none
	 */
	public ChessPiece getPieceAtLocation(Point loc) {
		return board[loc.row][loc.col];
		
	}
	
	/**
	 * Overloader for movePiece (below)
	 * @param fromRow, fromCol, toRow, toCol(int)
	 * @return boolean true false
	 */
	public boolean movePiece(int fromRow, int fromCol, int toRow, int toCol) {
		Point from = new Point(fromRow, fromCol);
		Point to   = new Point(toRow, toCol);
		return movePiece(from, to);
	}
	
	/**
	 * Moves the piece at 'from' to the space at 'to'.
	 * Input parameters are zero-indexed Point objects 
	 * containing Row val (0-7) and Col val (0-7).
	 * 
	 * @param from: the space (supposedly) containing the piece to move
	 * @param to: 	the space to move the piece to
	 * @return boolean: true if move succeeded, false otherwise 
	 */
	public boolean movePiece(Point from, Point to) {
		boolean castling = false;
		if (isMoveValid(from, to)) {
			ChessPiece fromPiece = board[from.row][from.col];
			board[to.row][to.col] = board[from.row][from.col];
			board[from.row][from.col] = null;
			
			// canCastle becomes false if king or rook has been moved
			if (fromPiece.pieceType.equals("king")) {
				canCastleKingside  = false;
				canCastleQueenside = false;
				
				if (to.col == 7) {
					castling = true;
					int homeRow;
					if (this.color.equals("white"))
						homeRow = 0;
					else
						homeRow = 7;
					ChessPiece king 	 = board[homeRow][4];
					ChessPiece kingsRook = board[homeRow][7];
					board[homeRow][6] = king;
					board[homeRow][5] = kingsRook;
					board[homeRow][4] = null;
					board[homeRow][7] = null;
					king.setPosition(new Point(homeRow,6));
					kingsRook.setPosition(new Point(homeRow,5));
				} else if (to.col == 0) {
					castling = true;
					int homeRow;
					if (this.color.equals("white"))
						homeRow = 0;
					else
						homeRow = 7;
					ChessPiece king 	  = board[homeRow][4];
					ChessPiece queensRook = board[homeRow][0];
					board[homeRow][2] = king;
					board[homeRow][3] = queensRook;
					board[homeRow][4] = null;
					board[homeRow][0] = null;
					king.setPosition(new Point(homeRow,2));
					queensRook.setPosition(new Point(homeRow,3));
				}
			}
			if (this.color == "white") {
				if (from.row == 0 && from.col == 0)
					canCastleQueenside = false;
				else if (from.row == 0 && from.col == 7)
					canCastleKingside = false;
			} else {
				if (from.row == 7 && from.col == 0)
					canCastleQueenside = false;
				else if (from.row == 0 && from.col == 7)
					canCastleKingside = false;
			}
			
			if (!castling) {
				fromPiece.setPosition(to);
//				fromPiece.resetReach();
			}
			setChanged();
			notifyObservers(board);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Given two Point coordinates (from and to),
	 * determines if the move is possible and legal.
	 * Note: this method does not perform a move.
	 * 
	 * @param Point from: the location of the piece to move (supposedly)
	 * @param Point   to: the location that the piece should be moved to
	 * @return   boolean: true if the move is legal, false otherwise.
	 */
	public boolean isMoveValid(Point from, Point to) {
		ChessPiece fromPiece = board[from.row][from.col];
		ChessPiece toPiece   = board[to.row][to.col];
		if (from.equals(to)) {
			return false; // not a move
		}
		// check if there is a piece to move
		if (fromPiece == null)  {
			return false;
		}
		// check if the piece at from is yours
		if ( ! fromPiece.color.toLowerCase().equals(this.color.toLowerCase())) {
			return false;
		}
		// check if it is capable of moving there
		if ( ! fromPiece.canReach(to)) {
			return false;
		}
		// check if the end square has one of your pieces
		if (toPiece != null && toPiece.color.equals(this.color) ) {
			if (toPiece.pieceType.equals("rook")) {
				if (castlingKingside(from, to) || castlingQueenside(from, to)) {
					return true;
				}
			}
			return false;
		}
		// if it's a pawn, make sure it's allowed there
		if (fromPiece.pieceType.toLowerCase().equals("pawn")) {
			if ( ! pawnAllowed(from, to)) {
				return false;
			}
		}
		// check spaces in between
		if ( ! isPathClear(from, to)) {
			return false;
		}
		// check if this move would end with you being in check 
		if ( (!allowPinPull) && thisMoveWouldPutMeInCheck(from, to) ) {
			return false;
		}
		return true;
	}
	
	/**
	 * Returns the possible spaces that the piece at the 
	 * given location can move to, as a Set of Point objects.
	 * 
	 * @param location: the space where the piece is, as a Point object
	 * @return Set<Point>: a set of the locations that it can move to - 
	 * 						returns null if there is no piece at given location
	 */
	public Set<Point> getPiecesMoves(Point location) {
		Set<Point> result = new HashSet<>();
		if (board[location.row][location.col] == null)
			return null;
		for (int row = 0; row < 8; row++) {
			for (int col = 0; col < 8; col++) {
				Point end = new Point(row, col);
				if (isMoveValid(location, end)) {
					result.add(end);
				}
			}
		}
		return result;
	}
	
	/**
	 * For a pawn, determines if it is allowed to make the given move.
	 * Does not execute the move.
	 * 
	 * @param from: the space, as a Point object, where the pawn is located
	 * @param   to: the space, as a Point object, that the pawn is being moved to
	 * @reurn boolean: 	true if the move is valid (or if the piece is not a pawn),
	 * 				 	false otherwise
	 */
	private boolean pawnAllowed(Point from, Point to) {
		if (from.col != to.col) {  // if move is diagonal
			if (getPieceAtLocation(to) == null)
				return false;
			else
				return true;
		}
		if (from.row+1 == to.row || from.row-1 == to.row) { // if move is one space
			if (getPieceAtLocation(to) == null)
				return true;
			else
				return false;		
		}
		if (from.row == 1 || from.row == 6) // the only option left - two spaces ahead 
			if (getPieceAtLocation(to) == null)
				return true;
			else
				return false;	
		return false;
	}

	/**
	 * Determines if this move is a legal castle on the King side,
	 * and Performs the Move.
	 * 
	 * @param from: the space where the king is
	 * 			to: the space sending the king to (the rook)
	 * @return boolean: true if this is a legal castle kingside, false otherwise
	 */
	private boolean castlingKingside(Point from, Point to) {
		if ( ! canCastleKingside)
			return false;
		int homeRow;
		if (this.color.equals("white"))
			homeRow = 0;
		else
			homeRow = 7;
		if (from.row == homeRow && from.col == 4 
				&& getPieceAtLocation(from).pieceType.equals("king")) {
			if (to.row == homeRow && to.col == 7
					&& getPieceAtLocation(to).pieceType.equals("rook")) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Determines if this move is a legal castle on the Queen side,
	 * and Performs the Move.
	 * 
	 * @param from: the space where the king is
	 * 			to: the space sending the king to
	 * @return boolean: true if this is a legal castle queenside, false otherwise
	 */
	private boolean castlingQueenside(Point from, Point to) {
		if ( ! canCastleQueenside)
			return false;
		int homeRow;
		if (this.color.equals("white"))
			homeRow = 0;
		else
			homeRow = 7;
		if (from.row == homeRow && from.col == 4 && 
				getPieceAtLocation(from).pieceType.equals("king")) {
			if (to.row == homeRow && to.col == 0
					&& getPieceAtLocation(to).pieceType.equals("rook")) {
				return true;				
			}
		}
		return false;
	}
	
	/**
	 * Checks whether or not there is only blank spaces between start and end,
	 * not counting the start and end spaces themselves.
	 * @return boolean: true if the path is clear, false otherwise
	 */
	public boolean isPathClear(Point start, Point end) {
		// for hortizontal moves
		if (start.row == end.row)
			if (start.col < end.col) { // to the right
				for (int col = start.col + 1; col < end.col; col++)
					if (board[start.row][col] != null)
						return false;
			} else { // to the left
				for (int col = start.col - 1; col > end.col; col--)
					if (board[start.row][col] != null)
						return false;
			}
		// for vertical moves
		if (start.col == end.col)
			if (start.row < end.row) { // moving up
				for (int row = start.row + 1; row < end.row; row++)
					if (board[row][start.col] != null)
						return false;
			} else { // moving down
				for (int row = start.row - 1; row > end.row; row--)
					if (board[row][start.col] != null)
						return false;
			}
		// for upward diagonal
		if (start.row - start.col == end.row - end.col) {
			Point temp = new Point(start);
			if (start.row > end.row) { // moving down+left
				while (temp.row > end.row + 1) {
					temp.row--;
					temp.col--;
					if (board[temp.row][temp.col] != null)
						return false;
				}
			} else { // moving up+right
				while (temp.row < end.row - 1) {
					temp.row++;
					temp.col++;
					if (board[temp.row][temp.col] != null)
						return false;
				}
			}
		}
		// for downward diagonal
		if (start.row - end.row == end.col - start.col) {
			Point temp = new Point(start);
			if (start.row - end.row > 0) { // moving down+right
				while (temp.row > end.row + 1) {
					temp.row--;
					temp.col++;
					if (board[temp.row][temp.col] != null)
						return false;
				}
			} else { // moving up+left
				while (temp.row < end.row - 1) {
					temp.row++;
					temp.col--;
					if (board[temp.row][temp.col] != null)
						return false;
				}
			}
		}
		return true;
	}
	
	/**
	 * Given a pair of locations, determines if the corresponding move
	 * would result in the player putting himself in check.
	 * 
	 * @param from: the location of the piece being moved.
	 * @param   to: the location to move the piece to.
	 * @return boolean: true if this move would result in check, false otherwise.
	 * 
	 */
	private boolean thisMoveWouldPutMeInCheck(Point from, Point to) {
		boolean ans;
		ChessPiece[][] boardBuffer = copyGrid(board);
		boolean canCastleKingsideBuffer  = canCastleKingside;
		boolean canCastleQueensideBuffer = canCastleQueenside;
		
		board[to.row][to.col] = board[from.row][from.col];
		board[from.row][from.col] = null;
		getPieceAtLocation(to).setPosition(to);
		
		if (inCheck(this.color))
			ans = true;
		else 
			ans = false;
		
		board = copyGrid(boardBuffer);
		canCastleKingside  = canCastleKingsideBuffer;
		canCastleQueenside = canCastleQueensideBuffer;
		getPieceAtLocation(from).setPosition(from);
		return ans;
	}
	
	private ChessPiece[][] copyGrid(ChessPiece[][] board) {
		ChessPiece[][] boardCopy = new ChessPiece[8][8];
		for (int row = 0; row < 8; row ++)
			System.arraycopy(board[row], 0, boardCopy[row], 0, 8);
		return boardCopy;
	}
	
	/**
	 * Determines if this player (color) is in check.
	 * @param color: "white" to determine if white is in check,
	 * 				 "black" to determine if black is in check
	 * @return boolean: true if in check, false otherwise
	 */
	public boolean inCheck(String color) {
		Point myKingsLocation = null;
		for (int row = 0; row < 8; row++) {
			for (int col = 0; col < 8; col++) {
				if ( board[row][col] != null
						&& board[row][col].color.equals(color)
						&& board[row][col].pieceType.toLowerCase().equals("king")) {
					myKingsLocation = new Point(board[row][col].position);
				}
			}
		}
		String opponentColor = "";
		if (color.toLowerCase().equals("white"))
			opponentColor = "black";
		else if (color.toLowerCase().equals("black"))
			opponentColor = "white";
		else
			System.out.println("ERROR inCheck(): bad color");
		allowPinPull = true;
		Set<SimpleEntry<Point, Point>> opponentMoveset = moveset(opponentColor);
		allowPinPull = false;
		for (SimpleEntry<Point, Point> entry : opponentMoveset) {
			if (entry.getValue().equals(myKingsLocation))
				return true;
		}
		return false;
	}
	
	/**
	 * Is Game Over (win, lose, or stalemate)
	 * @return boolean: true if game is over, false otherwise
	 */
	public boolean isGameOver() {
		if (gameOverBlock) {
			return false;
		}
		return (iWin() || iLose() || stalemate());		
	}
	
	/**
	 * Determines if the player has won the game, by putting the opponent in Checkmate.
	 * 
	 * @return boolean: true if this player has won, false otherwise
	 */
	public boolean iWin() {
		if (gameOverBlock)
			return false;
		// if opponent is in check AND has no legal moves
		String opponentColor;
		if (this.color.toLowerCase().equals("white"))
			opponentColor = "black";
		else 
			opponentColor = "white";
		if ( ! inCheck(opponentColor))
			return false;
		Set<SimpleEntry<Point, Point>> opponentMoveset = moveset(opponentColor);
		if (opponentMoveset.size() != 0)
			return false;
		return true;
	}
	
	/**
	 * Determines if the player has lost the game, by being put in Checkmate.
	 * 
	 * @return boolean: true if this player has lost, false otherwise
	 */
	public boolean iLose() {
		if (gameOverBlock)
			return false;
		// if I am in check and have no legal moves
		if ( ! inCheck(this.color))
			return false;
		Set<SimpleEntry<Point, Point>> moveset = moveset(this.color);
		if (moveset.size() != 0)
			return false;
		return true;
	}
	
	/**
	 * Determines if a stalemate has occurred, meaning the game has been tied.
	 * 
	 * Only returns true in these situations:
	 * 		- There are no pawns left AND each player has Wealth < 500
	 *		- This player is not in check and cannot make any legal moves.
	 *		- Opponent is not in check and cannot make any legal moves.
	 *
	 * @return boolean: true if stalemate, false otherwise
	 */
	public boolean stalemate() {
		if (gameOverBlock)
			return false;
		Boardstate state = wealths();
		if (state.pawnsPresent == false
				&& state.myWealth < 500 && state.hisWealth < 500) {
			return true;
		}
		String opponentColor;
		if (this.color.equals("white"))
			opponentColor = "black";
		else 
			opponentColor = "white";
		
		if ( (!inCheck(this.color)) && moveset(this.color).size() == 0 )
			return true;
		if ( (!inCheck(opponentColor)) && moveset(opponentColor).size() == 0 )
			return true;
		return false;
	}
	
	/**
	 * Calculates the player's advantage over the opponent,
	 * based on the 'wealth' of each player (the total value of his pieces),
	 * and the number of possible moves he could make (used as a tiebraker).
	 * Returns the Difference between the player's score and the opponent's,
	 * so a value of zero indicates no advantage (like at the start of the game),
	 * and a negative value indicates that the opponent has the advantage.
	 * 
	 * @return int: this player's advantage as an int (either positive, negative, or zero)
	 */
	public int myAdvantage() {
		return wealths().myAdvantage;
	}
	
	/**
	 * Overloader for myAdvantage(), takes a given chessboard
	 * @param inputBoard: a chessBoard in any state
	 * @return int: this player's advantage 
	 */
	private int myAdvantage(String color, ChessPiece[][] inputBoard) {
		ChessPiece[][] boardBuffer = copyGrid(board);
		String colorBuffer = this.color;
		board = copyGrid(inputBoard);
		this.color = color;
		int result = myAdvantage();
		board = copyGrid(boardBuffer);
		this.color = colorBuffer;
		return result;
	}
	
	/**
	 * Returns the total value of the player's pieces currently on the board.
	 * 
	 * @return int: the value of this player's pieces
	 */
	public int myWealth() {
		return wealths().myWealth;
	}
	
	/**
	 * Returns the total value of the opponent's pieces currently on the board.
	 * 
	 * @return int: the value of the opponent's pieces
	 */
	public int hisWealth() {
		return wealths().hisWealth;
	}
	
	/**
	 * Private inner class Boardstate.
	 * Holds information about the state of the board at the current time,
	 * such as the points of each player, the player's advantage,
	 * and whether pawns are present on the board.
	 */
	private class Boardstate {
		private int myWealth;
		private int hisWealth;
		private int myAdvantage;
		private boolean pawnsPresent;
		
		private Boardstate() {
			myWealth = 0;
			hisWealth = 0;
			myAdvantage = 0;
			pawnsPresent = false;
		}
	}
	
	/**
	 * Returns the total value of each players' pieces currently on the board.
	 * Pawns are worth 100pts each, Knight 325, Bishop 325, Rook 500, Queen 975.
	 * These units are technically what are known in chess as 'centipawns'.
	 * The King is priceless.
	 * 'myAdvantage' is calculated as the differences in wealth, 
	 * plus the difference in number of available moves - used as a tiebraker. 
	 * 
	 * @return Boardstate: a custom class (above) carrying the current info of the board.
	 */
	private Boardstate wealths() {
		Boardstate state = new Boardstate();
		state.myWealth  = 0;
		state.hisWealth = 0;
		state.pawnsPresent = false;
		String hisColor = "";
		if (this.color.equals("white"))
			hisColor = "black";
		else
			hisColor = "white";
		String myColor = this.color;
		int value = 0;
		for (int row = 0; row < 8; row++) {
			for (int col = 0; col < 8; col++) {
				if (board[row][col] == null) 
					continue;
				switch (board[row][col].pieceType) {
				case "pawn":
					value = 100;
					state.pawnsPresent = true;
					break;
				case "knight":
					value = 325;
					break;
				case "bishop":
					value = 325;
					break;
				case "rook":
					value = 500;
					break;
				case "queen":
					value = 975;
					break;
				default:
					value = 0; // king
					break;
				}
				if (board[row][col].color.toLowerCase().equals(myColor))
					state.myWealth  += value;
				else
					state.hisWealth += value;
			}
		}
		state.myAdvantage = (state.myWealth + moveset(myColor).size()) 
				- (state.hisWealth + moveset(hisColor).size());
//		state.myAdvantage = state.myWealth - state.hisWealth;
		return state;
	}
	
	/**
	 * Given an already verified valid move, performs the move on a given input board.
	 * Does not do any checking to make sure the move is valid.
	 * 
	 * @param 		from: the space to move a piece from
	 * @param         to: the space to move the piece to
	 * @param boardImage: a chessboard layout to perform the move on 
	 */
	private boolean makeVerifiedMove(Point from, Point to, ChessPiece[][] boardImage) {
		if (boardImage[from.row][from.col] == null) {
			System.out.println("makeVerifiedMove(): ERROR bad input move:"+from+" to "+to);
			return false;
		}
		boardImage[to.row][to.col] = boardImage[from.row][from.col];
		boardImage[from.row][from.col] = null;
		boardImage[to.row][to.col].setPosition(to);
		return false;
	}
	
	/**
	 * Chooses a random move to make, and performs it.
	 * @return boolean: true if success, false if there are no legal moves available.
	 */
	public boolean makeRandomMove() {
		if (isGameOver()) {
			System.out.println("makeRandomMove(): game over");
			return false;
		}
		Set<SimpleEntry<Point, Point>> moveset = moveset(this.color);
		if (moveset.size() == 0)
			return false;
		int randIndex = randomInt(0, moveset.size()-1);
		SimpleEntry<Point, Point> randEntry = null;
		int index = 0;
		for (SimpleEntry<Point, Point> entry : moveset) {
			if (index == randIndex)
				randEntry = entry;
			index++;
		}
		return makeVerifiedMove(randEntry.getKey(), randEntry.getValue(), board);
	}
	
//	/**
//	 * Overloader for makeRandomMove, makes the move on a given chessboard
//	 * 
//	 * @param inputBoard: the board to make a move on
//	 * @return boolean: true if move was executed, false otherwise
//	 */
//	private boolean makeRandomMove(ChessPiece[][] inputBoard) {
//		if (isGameOver()) {
//			System.out.println("makeRandomMove(): game over");
//			return false;
//		}
//		Set<SimpleEntry<Point, Point>> moveset = moveset(this.color, inputBoard);
//		if (moveset.size() == 0)
//			return false;
//		int randIndex = randomInt(0, moveset.size()-1);
//		SimpleEntry<Point, Point> randEntry = null;
//		int index = 0;
//		for (SimpleEntry<Point, Point> entry : moveset) {
//			if (index == randIndex)
//				randEntry = entry;
//			index++;
//		}
//		return makeVerifiedMove(randEntry.getKey(), randEntry.getValue(), inputBoard);
//	}
	
	/**
	 * boolean makeHardMove();
	 * Performs the move that provides the greatest gain of advantage,
	 * taking into consideration the opponent's best move as well.
	 * 
	 * @return boolean: true if the move was executed successfully,
	 * 					false if a move could not be performed. 
	 */
	public boolean makeHardMove() {
		gameOverBlock = true;
		
		// opponentColor
		String opponentColor;
		if (this.color.toLowerCase().equals("white"))
			opponentColor = "black";
		else
			opponentColor = "white";
		String myColor = this.color;
		
		// copy board
		ChessPiece[][] boardCopy = copyGrid(board);
		int maxMin = Integer.MIN_VALUE;
		SimpleEntry<Point, Point> bestMove = null;
		Set<SimpleEntry<Point, Point>> myMoveset = moveset(myColor, boardCopy);
		for (SimpleEntry<Point, Point> move : myMoveset) {
			this.color = myColor;
			makeVerifiedMove(move.getKey(), move.getValue(), boardCopy);
			gameOverBlock = false;
			if (iWin()) {
				board = copyGrid(boardCopy);
				return true;
			}
			gameOverBlock = true;
			this.color = opponentColor;
			Set<SimpleEntry<Point, Point>> opponentMoveset = moveset(opponentColor, boardCopy); 	
			int minAdvantage = Integer.MAX_VALUE;
			// for every move in opponentMoveset:
			for (SimpleEntry<Point, Point> oppMove : opponentMoveset) {
				this.color = opponentColor;
				makeVerifiedMove(oppMove.getKey(), oppMove.getValue(), boardCopy);
				this.color = myColor;
				int myAdvantage = myAdvantage(myColor, boardCopy);
				gameOverBlock = false;
				if (iLose())
					myAdvantage = -10000;
				gameOverBlock = true;
				if (myAdvantage < minAdvantage) {
					minAdvantage = myAdvantage;
				}
				if (myAdvantage < maxMin) {
					boardCopy = copyGrid(board);
					break;
				}
				// reset board
				boardCopy = copyGrid(board);
			}
			if (minAdvantage > maxMin) {
				maxMin = minAdvantage;
				bestMove = move;
			}
		}
		this.color = myColor;
		if (bestMove != null) {
			makeVerifiedMove(bestMove.getKey(), bestMove.getValue(), board);
		} else {
			System.out.println("ERROR in makeHardMove(): bestMove null");
			return false;
		}
		
		gameOverBlock = false;
		return true;
	}
	
	/**
	 * Just makes a random move. 
	 * 
	 * @return boolean: true if the move was executed, false otherwise  
	 */
	public boolean makeMediumMove() {
		return makeRandomMove();
	}
	
	/**
	 * Just makes a random move. 
	 * 
	 * @return boolean: true if the move was executed, false otherwise  
	 */
	public boolean makeEasyMove() {
		return makeRandomMove();
	}
	
//	/**
//	 * Intreguing idea (if there's time):
//	 * makeZeroMove();
//	 * Uses the engine Leela Chess Zero's algorithm of monte-carlo/depth-first
//	 * searching to choose a move with the highest possibility of a win.  
//	 * (No need to compare scores and advantages.)
//	 * 
//	 * NOTE: Not used, didn't have time to fully implement.
//	 * 
//	 */
//	public boolean makeZeroMove() {
//		int iterations = 1;  // ITERATIONS
//		
//		ChessPiece[][] boardCopy = copyGrid(board);
//		Set<SimpleEntry<Point, Point>> moveset = moveset(this.color);
//		if (moveset.isEmpty())
//			return false;
//		Map<SimpleEntry<Point, Point>, Integer> moveTable = new HashMap<>();
//		int maxPoints = 0;
//		SimpleEntry<Point, Point> bestMove = null;
//		
//		String opponentColor;
//		if (this.color.toLowerCase().equals("white"))
//			opponentColor = "black";
//		else
//			opponentColor = "white";
//		String myColor = this.color;
//		
//		for (int i = 0; i < iterations; i++) {
//			// for each move in the moveset
//				// choose a random move for opponent,
//				// choose a random response, repeat until game over
//			// add that data point to this move (win, loss, stalemate)
//			// if this move's points are higher than maxPoints, set it to bestMove
//			System.out.println("moveset: "+moveset.size());
//			for (SimpleEntry<Point, Point> move : moveset) {
//				makeVerifiedMove(move.getKey(), move.getValue(), boardCopy);
//				while ( ! isGameOver()) { // check if this works
//					if (this.color.equals(myColor))
//						this.color = opponentColor;
//					else
//						this.color = myColor;
//					makeRandomMove(boardCopy);
//				}
//				if (iWin())
//					System.out.println("zero: "+ move.getKey()+" to "+move.getValue() +": i Win : " + myColor);
//				if (iLose())
//					System.out.println("zero: "+ move.getKey()+" to "+move.getValue() +": i Lose : " + myColor);
//				if (stalemate())
//					System.out.println("zero: "+ move.getKey()+" to "+move.getValue() +": stalemate");
//				// put data in map
//				
//				// reset the board
//				boardCopy = copyGrid(board);
//			}
//			
//		}
//		// if bestMove is null, Error
//		// make bestMove, return true
//		return true;  // make false condition
//	}
	
	/**
	 * Creates and returns the Set of all possible moves
	 * 
	 * @param color: a String, either "white" or "black"  
	 * @return  Set: a set of Map.Entry<Point, Point> objects, basically tuples of Points.
	 */
	public Set<SimpleEntry<Point, Point>> moveset(String color) {	
		promotePawns();
		String colorBuffer = this.color;
		this.color = color;
		Set<SimpleEntry<Point, Point>> moveset = new HashSet<>();
		for (int fromRow = 0; fromRow < 8; fromRow++ ) {
			for (int fromCol = 0; fromCol < 8; fromCol++) {
				if (board[fromRow][fromCol] != null 
						&& board[fromRow][fromCol].color.equals(color)) {
					// for each of my pieces
					for (int toRow = 0; toRow < 8; toRow++ ) {
						for (int toCol = 0; toCol < 8; toCol++) {
							// can it go here
							Point from = new Point(fromRow, fromCol);
							Point to = new Point(toRow, toCol);
							if (isMoveValid(from, to)) {
								moveset.add(new SimpleEntry<>(from, to));
							}
						}
					}
				}
			}
		} 		
		this.color = colorBuffer;
		return moveset;
	}
	
	/**
	 * Overloader for moveset() based on a given chessboard
	 */
	public Set<SimpleEntry<Point, Point>> moveset(String color, ChessPiece[][] inputBoard) {
		ChessPiece[][] boardBuffer = copyGrid(board);
		board = copyGrid(inputBoard);
		Set<SimpleEntry<Point, Point>> result = moveset(color);
		board = copyGrid(boardBuffer);
		return result;
	}
	
	/**
	 * Checks if there are pawns to promote, and if so, makes them all queens.
	 */
	private void promotePawns() {
		for (int col = 0; col < 8; col++) {
			if (board[0][col] != null && board[0][col].pieceType.equals("pawn")) {
				board[0][col] = new Queen("black", "queen", new Point(0,col));
			}
			if (board[7][col] != null && board[7][col].pieceType.equals("pawn")) {
				board[7][col] = new Queen("white", "queen", new Point(7,col));
			}
		}
	}
	
	/**
	 * Returns a random int between min and max, inclusive
	 * 
	 * @param  min: minimum int that the random int could be
	 * @param  max: maximum int that the random int could be
	 * @return int: the random int
	 */
	public int randomInt(int min, int max) {
		return ThreadLocalRandom.current().nextInt(min, max + 1);
	}

}
