import java.io.Serializable;

/**
 * @author Team9
 * 
 * This class serves as a representation of a bishop piece. We will
 * be using our ChessPiece class.
 */

public class Bishop extends ChessPiece implements Serializable {
	
	/**
	 * Constructor for Bishop class.
	 * @param color that the piece needs to be depending on the player.
	 * @param pieceType represents the type of the piece.
	 * @param position of what this piece needs to be at.
	 */
	public Bishop(String color, String pieceType, Point position) {
		super(color, pieceType, position);
	}
	
	@Override
	void resetReach() {
		reachableSpaces.clear();
		Point temp = new Point(position.row, position.col);
		// for the bishop's upward diagonal
		while (temp.row != 0 && temp.col != 0) {
			temp.row--;
			temp.col--;
		}
		while (inBounds(temp)) {
			if ( ! temp.equals(position))
				reachableSpaces.add(new Point(temp));
			temp.row++;
			temp.col++;
		}
		// for the bishop's downward diagonal
		temp = new Point(position.row, position.col);
		while (temp.row != 7 && temp.col != 0) {
			temp.row++;
			temp.col--;
		}
		while (inBounds(temp)) {
			if ( ! temp.equals(position))
				reachableSpaces.add(new Point(temp));
			temp.row--;
			temp.col++;
		}
	}
	
}
