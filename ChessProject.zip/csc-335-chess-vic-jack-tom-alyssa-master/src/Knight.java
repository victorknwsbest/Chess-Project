import java.io.Serializable;

/**
 * @author Team9
 * 
 * This class serves as a representation of a knight piece,
 * will also be using the ChessPiece class that we have also
 * created.
 */

public class Knight extends ChessPiece implements Serializable {
	
	/**
	 * @param color that the piece needs to be depending on the player.
	 * @param pieceType represents the type of the piece.
	 * @param position of what this piece needs to be at.
	 */
	public Knight(String color, String pieceType, Point position) {
		super(color, pieceType, position);
	}
	
	@Override
	void resetReach() {
		reachableSpaces.clear();
		Point temp = new Point(0,0);
		temp.col = position.col - 2;
			temp.row = position.row + 1;
			conditionalAdd(new Point(temp));
			temp.row = position.row - 1; 
			conditionalAdd(new Point(temp));
		temp.col = position.col - 1;
			temp.row = position.row + 2;
			conditionalAdd(new Point(temp));
			temp.row = position.row - 2;
			conditionalAdd(new Point(temp));
		temp.col = position.col + 1;
			temp.row = position.row + 2;
			conditionalAdd(new Point(temp));
			temp.row = position.row - 2;
			conditionalAdd(new Point(temp));
		temp.col = position.col + 2;
			temp.row = position.row + 1;
			conditionalAdd(new Point(temp));
			temp.row = position.row - 1;
			conditionalAdd(new Point(temp));
	}
	
	void conditionalAdd(Point p) {
		if (inBounds(p))
			reachableSpaces.add(p);
	}

}
