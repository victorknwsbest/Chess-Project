import java.io.Serializable;

/**
 * @author Team9
 * 
 * This class serves as a representation of a queen piece
 */

public class Queen extends ChessPiece implements Serializable {
	/**
	 * Constructor
	 * @param color that the piece needs to be depending on the player.
	 * @param pieceType represents the type of the piece.
	 * @param position of what this piece needs to be at.
	 */
	public Queen(String color, String pieceType, Point position) {
		super(color, pieceType, position);
	}

	@Override
	void resetReach() {
		reachableSpaces.clear();
		Point temp = new Point(0,0);
		// algorithm from Rook class
		for (int col = 0; col < 8; col++) {
			temp.col = col;
			temp.row = position.row;
			if (temp.equals(position))
				continue;
			reachableSpaces.add(new Point(temp));
		}
		for (int row = 0; row < 8; row++) {
			temp.col = position.col;
			temp.row = row;
			if (temp.equals(position))
				continue;
			reachableSpaces.add(new Point(temp));
		}
		// algorithm from Bishop class
		temp.row = position.row;
		temp.col = position.col;
		while (temp.row != 0 && temp.col != 0) {
			temp.row--;
			temp.col--;
		}
		while (inBounds(temp)) {
			if ( ! temp.equals(position))
				reachableSpaces.add(new Point(temp));
			temp.row++;
			temp.col++;
		}
		temp.row = position.row;
		temp.col = position.col;
		while (temp.row != 7 && temp.col != 0) {
			temp.row++;
			temp.col--;
		}
		while (inBounds(temp)) {
			if ( ! temp.equals(position))
				reachableSpaces.add(new Point(temp));
			temp.row--;
			temp.col++;
		}
	}

}
