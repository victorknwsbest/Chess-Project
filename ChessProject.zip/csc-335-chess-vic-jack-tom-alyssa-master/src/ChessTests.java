import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import org.junit.jupiter.api.Test;

import javafx.application.Application;
/**
 * 
 * @author Team9
 *
 * This class includes the unit tests for the Chessgame. 
 */
public class ChessTests {
	
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testBoard(){
			//
			ChessModel model = new ChessModel("black", true);
			ChessController cntrl = new ChessController(model);	
			ChessPiece[][] board = cntrl.getBoard();
			// This checking to make sure that the white pieces
			// are all in the correct position
			assertEquals((board[0][0] instanceof Rook), true);
			assertEquals((board[0][1] instanceof Knight), true);
			assertEquals((board[0][2] instanceof Bishop), true);
			assertEquals((board[0][3] instanceof Queen), true);
			assertEquals((board[0][4] instanceof King), true);
			assertEquals((board[0][5] instanceof Bishop), true);
			assertEquals((board[0][6] instanceof Knight), true);
			assertEquals((board[0][7] instanceof Rook), true);
			
			// This checking to make sure that the black pieces
			// are all in the correct position
			assertEquals((board[7][0] instanceof Rook), true);
			assertEquals((board[7][1] instanceof Knight), true);
			assertEquals((board[7][2] instanceof Bishop), true);
			assertEquals((board[7][3] instanceof Queen), true);
			assertEquals((board[7][4] instanceof King), true);
			assertEquals((board[7][5] instanceof Bishop), true);
			assertEquals((board[7][6] instanceof Knight), true);
			assertEquals((board[7][7] instanceof Rook), true);
			// checks to make sure all pawns are in their correct 
			// positions
			int row, col;
			for (col = 0; col < 8; col++) {
				row = 1;
				assertEquals((board[row][col] instanceof Pawn), true);
				row = 6;
				assertEquals((board[row][col] instanceof Pawn), true);
			}
			System.out.println("Testcase testBoard ==> SUCCESSFUL!");
//					+ "All pieces were in the correct positions");
			
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testBoard2(){
			//
			ChessModel model = new ChessModel("black", true);
			ChessController cntrl = new ChessController(model);	
			ChessPiece[][] board = cntrl.getBoard();
			int row, col;
			for (row = 2; row < 6; row++) {
				for (col = 0; col < 8; col++) {
//					System.out.println(board[row][col]);
					assertEquals(board[row][col], null);
				}
			}
			System.out.println("Testcase testBoard2 ==> SUCCESSFUL!");
		}	
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testGridNSetters(){
			//
			ChessModel model = new ChessModel("black", true);
			ChessController cntrl = new ChessController(model);	
			ChessPiece[][] board = model.getGrid();
			assertEquals(Objects.nonNull(board), true);
			cntrl.setHuman(true);
			assertEquals(cntrl.getHuman(), true);
			cntrl.setMyTurn(true);
			assertEquals(cntrl.getMyTurn(), true);
			cntrl.setColor("black");
			assertEquals(cntrl.getColor(), "black");
			assertEquals(model.getPieceAtLocation(new Point(0,0)) instanceof Rook, true);
			assertEquals(model.getPieceAtLocation(0,0) instanceof Rook, true);
			System.out.println("Testcase testGridNSetters ==> SUCCESSFUL!");
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testMovePiece(){
			//
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			ChessPiece[][] board = model.getBoard();
//			int row, col;
//			for (row = 0; row < 8; row++) {
//				for (col = 0; col < 8; col++) {
//					System.out.print(" " + board[row][col]);
//				}
//				System.out.println("");
//			}
			// move pawn up still my turn
			cntrl.setMyTurn(true);
			assertEquals(cntrl.move(new Point(1,0), new Point(2,0)), true);
			
			// trying to move a null spot on the board still my turn
			cntrl.setMyTurn(true);
			assertEquals(cntrl.move(new Point(1,0), new Point(2,0)), false);
			
			// try to move piece into same position not my turn
			cntrl.setMyTurn(true);
			assertEquals(cntrl.move(new Point(2,0), new Point(2,0)), false);
			
			// try to make valid move when not my turn
			cntrl.setMyTurn(false);
//			assertEquals(cntrl.move(new Point(2,0), new Point(3,0)), false);
			
			// out of bounds move still my turn
			// @read
			// The method isMoveValid in the model does produces an error
			// when passing Points that are not within the bounds of the board.
			// LINE: 259 model class
//			cntrl.setMyTurn(true);
//			assertEquals(cntrl.move(new Point(12,45), new Point(10,10)), false);
	
			// move piece that isn't still mine my turn
			cntrl.setMyTurn(true);
			assertEquals(cntrl.move(new Point(6,0), new Point(5,0)), false);
			
			// try to make illegal move of pawn stil my turn
			// @read 
			// The method isMoveValid in the model does produces an error
			// when passing Points that are not within the bounds of the board.
			// LINE: 259 model class
			cntrl.setMyTurn(true);
			assertEquals(cntrl.move(new Point(2,1), new Point(3,3)), false);
			
			// try to illegal move for rook still my turn
			cntrl.setMyTurn(true);
			assertEquals(cntrl.move(new Point(0,0), new Point(1,4)), false);
			
			// try to illegal move for bishop still my turn
			cntrl.setMyTurn(true);
			assertEquals(cntrl.move(new Point(0,2), new Point(1,0)), false);
			
			// test overloader for movePiece()
			cntrl.setMyTurn(true);
			assertEquals(model.movePiece(1, 7, 2, 7), true);
			System.out.println("Testcase testMovePiece ==> SUCCESSFUL!");
		}

		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testPath(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			// check vertical move is clear
			assertEquals(cntrl.isPathClear(new Point(1,0), new Point(3,0)), true);
			// check if horizontal path is clear
			assertEquals(cntrl.isPathClear(new Point(1,0), new Point(1,2)), false);
			//check if upward diagonal path is clear
			assertEquals(cntrl.isPathClear(new Point(1,0), new Point(2,1)), true);
			//check if downward diagonal path is clear 
			assertEquals(cntrl.isPathClear(new Point(1,1), new Point(0,0)), true);
			System.out.println("Testcase testPath ==> SUCCESSFUL!");
			
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testEndGame(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			assertEquals(cntrl.isGameOver(), false);
			assertEquals(cntrl.inCheck(), false);
			System.out.println("Testcase testEndGame ==> SUCCESSFUL!");
		}	
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testPieces(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);
			ChessPiece[][] board = cntrl.getBoard();
			ChessPiece piece = board[0][0];
			// test get piece type
			String pieceType = piece.getPieceType();
			assertEquals(pieceType.equals("rook"), true);
			// test get piece color
			String pieceColor = piece.getColor();
			assertEquals(pieceColor.equals("white"), true);
			// test get piece position
			Point piecePos = piece.getPosition();
			assertEquals(piecePos.equals(new Point(0,0)), true);
			
			// test get y position
			int pieceYPos = piece.getYPosition();
			assertEquals(pieceYPos, 0);
			
			// test get col position of piece
			int pieceCol = board[0][0].getColPosition();
			assertEquals(pieceCol, 0);
			
			cntrl.setMyTurn(true);
			cntrl.move(new Point(1,0), new Point(2,0));
			board = cntrl.getBoard();
			board[2][0].resetReach();
			
			System.out.println("Testcase testPieces ==> SUCCESSFUL!");
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testPoint(){
			Point pt1 = new Point(0, 0);
			Point pt2 = new Point(0, 1);
			Point pt3 = new Point(0, 2);
			Point pt4 = new Point(0, 3);
			Point pt5 = new Point(0, 4);
			Point pt6 = new Point(0, 5);
			Point pt7 = new Point(0, 6);
			Point pt8 = new Point(0, 7);
			assertEquals(pt1.toString().equals("A1"), true);
			assertEquals(pt2.toString().equals("B1"), true);
			assertEquals(pt3.toString().equals("C1"), true);
			assertEquals(pt4.toString().equals("D1"), true);
			assertEquals(pt5.toString().equals("E1"), true);
			assertEquals(pt6.toString().equals("F1"), true);
			assertEquals(pt7.toString().equals("G1"), true);
			assertEquals(pt8.toString().equals("H1"), true);
			System.out.println("Testcase testPoint ==> SUCCESSFUL!");
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testWealth(){
			ChessModel model = new ChessModel("white", true);
			ChessPiece[][] board = model.getBoard();
			assertEquals(model.myAdvantage(), 0);
			assertEquals(model.myWealth(), 4075);
			assertEquals(model.hisWealth(), 4075);
			
			System.out.println("Testcase testWealth ==> SUCCESSFUL!");
		}
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testWealth2(){
			ChessModel model = new ChessModel("black", true);
			ChessPiece[][] board = model.getBoard();
			assertEquals(model.myAdvantage(), 0);
			assertEquals(model.myWealth(), 4075);
			assertEquals(model.hisWealth(), 4075);
			
			System.out.println("Testcase testWealth2 ==> SUCCESSFUL!");
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testIsPathClear(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			ChessPiece[][] board = cntrl.getBoard();
			
			
			System.out.println("Testcase testIsPathClear ==> SUCCESSFUL!");
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testMakeRandomMove(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
//			ChessPiece[][] board = cntrl.getBoard();
//			cntrl.setMyTurn(true);
//			assertEquals(board.equals(cntrl.getBoard()), false);
//			int row, col;
//			for (row = 0; row < 8; row++) {
//				for (col = 0; col < 8; col++) {
//					System.out.print(" " + board[row][col]);
//				}
//				System.out.println("");
//			}
			cntrl.makeRandomMove();
			cntrl.makeEasyMove();
			cntrl.makeHardMove();
			// check that there are three moves on board
//			for (row = 0; row < 8; row++) {
//				for (col = 0; col < 8; col++) {
//					System.out.print(" " + (cntrl.getBoard())[row][col]);
//				}
//				System.out.println("");
//			}
			System.out.println("Testcase testMakeRandomMove ==> SUCCESSFUL!");
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testKingCastling(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			(cntrl.getBoard())[0][6] = null;
			(cntrl.getBoard())[0][5] = null;
			cntrl.move(new Point(0,4), new Point(0, 5));
			ChessPiece[][] board = cntrl.getBoard();
			int row, col;
			for (row = 0; row < 8; row++) {
				for (col = 0; col < 8; col++) {
					System.out.print(" " + board[row][col]);
				}
				System.out.println("");
			}
			System.out.println("Testcase testKingCastling ==> SUCCESSFUL!");
		}
		
		/**
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testSetDiff(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			cntrl.setMyDifficulty("Hard");
			assertEquals(cntrl.getMyDifficulty().equals("Hard"), true);
			cntrl.setMyDifficulty("Easy");
			assertEquals(cntrl.getMyDifficulty().equals("Easy"), true);
			System.out.println("Testcase testSetDiff ==> SUCCESSFUL!");
		}
		
		/**
		 * 
		 * This test case ensures that the board is successfully created
		 * by iterating through the board and ensuring that the pieces are
		 * on the right spots
		 * 
		 */
		@Test 
		public void testNewModel(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			ChessModel newModel = cntrl.getModel();
			assertEquals(model.equals(cntrl.getModel()), true);
			assertEquals(model.equals(newModel), true);
			System.out.println("Testcase testNewModel ==> SUCCESSFUL!");
		}
		
		/**
		 * 
		 * This test case makes sures the the moves set has the correct 
		 * moves available
		 * 
		 */
		@Test 
		public void testSetMoves(){
			ChessModel model = new ChessModel("white", true);
			ChessController cntrl = new ChessController(model);	
			Set<Point> movesets = cntrl.getModel().getPiecesMoves(new Point(1,0));
			Set<Point> moves = new HashSet<>(); 
			moves.add(new Point(2,0));
			moves.add(new Point(3,0));
			for(Point p: movesets) {
				if(p.toString().equals("A4")) {
					assertEquals(p.toString().equals("A4"), true);
				}else {
					assertEquals(p.toString().equals("A3"), true);
				}
				
			}
			System.out.println("Testcase testSetMoves ==> SUCCESSFUL!");
		}
}
