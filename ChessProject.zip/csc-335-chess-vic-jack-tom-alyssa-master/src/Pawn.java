import java.io.Serializable;

/**
 * @author Team9
 * 
 * This class serves as a representation of a pawn piece.
 */

public class Pawn extends ChessPiece implements Serializable {
	/**
	 * Constructor
	 * @param color that the piece needs to be depending on the player.
	 * @param pieceType represents the type of the piece.
	 * @param position of what this piece needs to be at.
	 */
	public Pawn(String color, String pieceType, Point position) {
		super(color, pieceType, position);
	}

	/*
	 * This method adds Four possible moves to this pawn's reachableSpaces set,
	 * two in front, and two diagonal capturing moves. It'll be up to the Model
	 * to determine if the pawn can move two spaces ahead, or if it can capture.
	 */
	@Override
	void resetReach() { 
		reachableSpaces.clear();
		Point temp = new Point(position);
		if (color.toLowerCase().equals("white")) {
			temp.row++;
				temp.col--;
				conditionalAdd(new Point(temp));
				temp.col++;
				conditionalAdd(new Point(temp));
				temp.col++;
				conditionalAdd(new Point(temp));
				temp.col--;
			temp.row++;
			conditionalAdd(new Point(temp));
		} else if (color.toLowerCase().equals("black")) {
			temp.row--;
				temp.col--;
				conditionalAdd(new Point(temp));
				temp.col++;
				conditionalAdd(new Point(temp));
				temp.col++;
				conditionalAdd(new Point(temp));
				temp.col--;
			temp.row--;
			conditionalAdd(new Point(temp));
		}	
	}
	
	void conditionalAdd(Point p) {
		if (inBounds(p))
			reachableSpaces.add(p);
	}

}
