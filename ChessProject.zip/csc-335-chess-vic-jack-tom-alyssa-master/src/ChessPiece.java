import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * @author: Team9
 * 
 * This class serves as an abstract class for the chess pieces and contains
 * methods and fields for color.
 */

public abstract class ChessPiece implements Serializable {
	
	protected String color;
	protected String pieceType;  // unused so far
	protected Point position;
	protected Set<Point> reachableSpaces;
	
	/**
	 * Constructor
	 * @param color that the piece needs to be depending on the player.
	 * @param pieceType represents the type of the piece.
	 * @param position of what this piece needs to be at.
	 */
	public ChessPiece(String color, String pieceType, Point position) {
		this.color = new String(color);
		this.pieceType = new String(pieceType);
		this.position = new Point(position);
		reachableSpaces = new HashSet<Point>();
		resetReach();
	}
	
	/**
	 * Getter
	 * @param N/A
	 * @returns the type of the piece as a string, like "pawn" or "king"
	 */
	public String getPieceType() {
		return pieceType;
	}
	/**
	 * Getter 
	 * @param N/A
	 * @returns the type of the piece as a string, like "pawn" or "king"
	 */
	public String getColor() {
		return color;
	}
	/**
	 * Getter
	 * @param N/A
	 * @returns position as a Point
	 */
	public Point getPosition() {
		return position;
	}
	
	/**
	 * Getter
	 * @param N/A
	 * @returns the row coordinate of the piece 
	 */
	public int getYPosition() {
		return position.row;
	}
	
	/**
	 * Getter
	 * @param N/A
	 * @returns the col coordinate of the piece 
	 */
	public int getColPosition() {
		return position.col;
	}
	
	/**
	 * Setter; Sets position on the board
	 * @param N/A
	 * @return N/A
	 */
	public void setPosition(Point coord) {
		this.position = coord;
		resetReach();
	}
	
	/**
	 * Determines if this piece can reach the given space in one move,
	 * not accounting for obstacles or illegal moves.
	 * @param to(point)
	 * @return boolean: true if it can, 
	 * 					false if it cannot reach the given space, 
	 * 					or if it is already on the given space. 
	 */
	boolean canReach(Point to) {
		for (Point p : reachableSpaces) {
			if (to.equals(p)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Called whenever this piece is moved, 
	 * this method resets the Set of spaces that this piece can reach in one move,
	 * not accounting for any obstacles on the board,
	 * and not counting the space that it is currently occupying.
	 * @param N/A
	 * @return N/A
	 */
	abstract void resetReach();
	
	/**
	 * For use in the subclasses,
	 * checks if a given point is within the bounds of the chess board.
	 * @param Point: the given point with int x and int y coordinates.
	 * @return boolean: true if the point is on the board (1,1)-(8,8),
	 * 					false if not.
	 */
	public boolean inBounds(Point p) {
		if (p.row >= 0 && p.row <= 7 && p.col >= 0 && p.col <= 7)
			return true;
		else
			return false;
	}
	
}
