import java.io.Serializable;

/**
 * @author Team9
 * 
 * This class serves as a representation of a king piece.
 */

public class King extends ChessPiece implements Serializable {
	
	/**
	 * Constructor for King class.
	 * @param color that the piece needs to be depending on the player.
	 * @param pieceType represents the type of the piece.
	 * @param position of what this piece needs to be at.
	 */
	public King(String color, String pieceType, Point position) {
		super(color, pieceType, position);
	}

	@Override
	void resetReach() {
		reachableSpaces.clear();
		Point temp = new Point(position.row, position.col);
		temp.col--;
			temp.row++;
			conditionalAdd(new Point(temp));
			temp.row--;
			conditionalAdd(new Point(temp));
			temp.row--;
			conditionalAdd(new Point(temp));
		temp.col++;
			conditionalAdd(new Point(temp));
			temp.row++;
			temp.row++;
			conditionalAdd(new Point(temp));
		temp.col++;
			conditionalAdd(new Point(temp));
			temp.row--;
			conditionalAdd(new Point(temp));
			temp.row--;
			conditionalAdd(new Point(temp));
	}
	
	void conditionalAdd(Point p) {
		if (inBounds(p))
			reachableSpaces.add(p);
	}

}
