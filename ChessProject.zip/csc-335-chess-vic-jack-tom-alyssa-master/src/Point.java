import java.io.Serializable;

/**
 * @author Team9
 * This is my version of the Point class, which only holds two integers:
 * a row value, and a col value.
 * This is to avoid confusion with the x and y values of Java's Point class.  
 */

public class Point implements Serializable {
	public int row;
	public int col;
	
	/**
	 * Constructor
	 * @param row: the row of the location on the board
	 * @param col: the column of the location
	 */
	public Point(int row, int col) {
		this.row = row;
		this.col = col;
	}
	
	/**
	 * Copy Constructor
	 * @param p represents another Point object
	 */
	public Point(Point p) {
		this.row = p.row;
		this.col = p.col;
	}
	
	/**
	 * Equals() method.
	 * 
	 * @param o represents an object, supposedly another Point to compare
	 * @return boolean: true if they are equivalent, false if not
	 */
	@Override
	public boolean equals(Object o) {
		if (o instanceof Point) {
			Point other = (Point) o;
			if (this.row == other.row
					&& this.col == other.col) {
				return true;
			}
		} 
		return false;
	}
	
	/**
	 * A toString() method
	 * Gives the location in chess notation (A4, E5, etc.)
	 * @return String: a location in chess notation
	 */
	@Override
	public String toString() {
		String result = "";
		switch (col) {
		case 0:
			result += "A";
			break;
		case 1:
			result += "B";
			break;
		case 2:
			result += "C";
			break;
		case 3:
			result += "D";
			break;
		case 4:
			result += "E";
			break;
		case 5:
			result += "F";
			break;
		case 6:
			result += "G";
			break;
		case 7:
			result += "H";
			break;
		default:
			break;
		}
		result += row+1;
		return result;
	}
}
