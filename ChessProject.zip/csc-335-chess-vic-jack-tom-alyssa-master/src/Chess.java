import javafx.application.Application;
/**
 * 
 * @author Team9
 *
 *	
 */
public class Chess {

	public static void main(String[] args) {
		Application.launch(ChessView.class, args);
	}

}
