import java.io.Serializable;
/**
 * 
 * @author Team9 
 */
public class ChessMoveMessage implements Serializable {
	private static final long serialVersionUID = 1L;
	
	public static final String WHITE = "white";
	public static final String BLACK = "black";
	
	private ChessPiece[][] board;
	
	/**
	 * 
	 * @param board(ChessPiece)
	 * @return N/A
	 */
	public ChessMoveMessage(ChessPiece[][] board) {
		this.board = board;
	}
	
	/**
	 * @param N/A
	 * @return board
	 */
	public ChessPiece[][] getUpdatedBoard() {
		return board;
	}
}
